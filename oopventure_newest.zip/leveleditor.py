# leveleditor.py
# Setup für lokales pygame (falls gebündelt)
try:
    from framework import setup_pygame
except ImportError:
    pass

import os
import json
import pygame
import tkinter as tk
from tkinter import filedialog, ttk

# -----------------------------
# Konfiguration
# -----------------------------
TILESIZE = 64
MARGIN = 8
MIN_W, MIN_H = 2, 2

# -----------------------------
# Basis-Tiles
# -----------------------------
TILES = {
    "1": ("w", "sprites/gras.png"),        # Weg/Gras
    "2": ("t", "sprites/baum.png"),        # zyklisch: Baum/Berg/Busch (Taste 2)
    "3": ("h", "sprites/herz.png"),        # Herz
    "4": ("v", "sprites/villager.png"),    # Dorfbewohner
    "5": ("x", "sprites/monster.png"),     # Monster
    "6": ("p", "sprites/held.png"),        # Held/Knappe: Taste 6 toggelt 'p' <-> 'k'
    "7": ("c", "sprites/code.png"),        # Code-Zettel
    "8": ("d", "sprites/tuer.png"),        # Tür
    "9": ("g", "sprites/tor_zu.png"),      # Tor (geschlossen)
}

# -----------------------------
# Zyklische Gruppen
# -----------------------------
TILE_GROUPS = {
    # Mehrfach '2' drücken -> t (Baum) -> m (Berg) -> b (Busch) -> t ...
    "2": [
        ("t", "sprites/baum.png"),
        ("m", "sprites/berg.png"),
        ("b", "sprites/busch.png"),
    ],
}

FALLBACK_COLORS = {
    "w": (50, 160, 50),
    "t": (34, 100, 34),
    "m": (120, 120, 120),
    "b": (20, 120, 20),
    "h": (220, 60, 60),
    "x": (60, 60, 220),
    "p": (220, 200, 60),
    "k": (200, 200, 220),
    "v": (150, 120, 60),
    "c": (220, 180, 60),
    "d": (150, 90, 40),
    "g": (150, 100, 40),
    "G": (180, 130, 60),
}


class LevelEditor:
    def __init__(self, start_w=4, start_h=4, tilesize=TILESIZE):
        pygame.init()
        pygame.display.set_caption("Level-Editor")

        # Zeit & Fonts
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("consolas", 18)
        self.big = pygame.font.SysFont("consolas", 22, bold=True)
        self.small = pygame.font.SysFont("consolas", 14)

        # Grid
        self.tilesize = tilesize
        self.grid_w = max(MIN_W, start_w)
        self.grid_h = max(MIN_H, start_h)
        self.level = [["w" for _ in range(self.grid_w)] for _ in range(self.grid_h)]

        # Auswahl
        self.selected_key = "1"
        self.selected_code = TILES[self.selected_key][0]
        self.tile_cycle_idx = {k: 0 for k in TILE_GROUPS}
        self._toggle_held_knappe = True  # True: 'p' (Held), False: 'k' (Knappe)
        # Tür/Schlüssel Farbauswahl (mehrfaches Drücken der Taste wechselt Farbe)
        self.door_colors = ["green", "violet", "blue", "golden", "red"]
        self.door_color_idx = 0
        self.selected_door_color = None
        self.key_colors = ["green", "violet", "blue", "golden", "red"]
        self.key_color_idx = 0
        self.selected_key_color = None
        # Villager gender selection (toggle with key '4')
        self.selected_villager_weiblich = False
        # Villager variant index: 0=male villager, 1=female villager, 2=Questgeber
        self.villager_variant_idx = 0
        # Persisted per-tile settings (colors for doors/keys, villagers genders)
        self.colors = {}
        self.villagers = {}
        # Persisted quest settings per tile
        self.quests = {}

        # Extra level-wide settings (initial_gold, quest_max_kosten, quest_mode, quest_items_needed)
        self.level_settings = {}

        # Victory condition settings (editable via F3)
        # Stored under level_settings['victory'] as a dict. Backwards-compatible default
        # is to require collecting all hearts.
        self.level_settings.setdefault('victory', {"collect_hearts": True, "move_to": None, "classes_present": False})

        # Class requirements (F4 menu)
        # Stores per-class configuration: methods, attributes, inheritance, use_student toggle
        # Format: {"Held": {"methods": ["geh", "links"], "attributes": ["hp"], "inherits": "Charakter", "use_student": True}, ...}
        self.class_requirements = {}

        # Hints / level help (F5)
        # Stores editable hint fields: text (list), code (list), phase (str), + preserved flags
        self.hints = {}

        # Sprites
        self.sprites = self._load_all_sprites()
        # Monster variant index (0 = default Monster 'x', 1 = Bogenschuetze 'y')
        self.monster_variant_idx = 0

        # Fenster
        self._recalc_window()
        self.screen = pygame.display.set_mode((self.win_w, self.win_h))

        # Schnellspeichern
        self.quick_mode = False
        self.quick_digits = ""

        # Privatisierungs-Flags (F1-Menü)
        self.privacy_flags = {
            "Held": False, "Knappe": False, "Monster": False,
            "Herz": False, "Tuer": False, "Zettel": False, "Villager": False,
            # Hindernisse (Baum/Busch/Berg) können privat gesetzt werden
            "Hindernis": False,
            # Schlüssel und Bogenschütze (separate von generischem Monster)
            "Schluessel": False,
            "Bogenschuetze": False
        }
        # Orientierungen pro Koordinate als dict "x,y" -> "up|right|down|left"
        self.orientations = {}

    # -----------------------------
    # Sprites
    # -----------------------------
    def _load_all_sprites(self):
        if not pygame.display.get_init():
            pygame.display.init()
        if not pygame.display.get_surface():
            pygame.display.set_mode((1, 1))

        sprites = {}
        for key, (code, path) in TILES.items():
            sprites[code] = self._load_sprite(path)

        # Bogenschuetze (variant of Monster) — optional sprite, fallbacks handled
        # use code 'y' internally to represent a placed Bogenschuetze
        sprites["y"] = self._load_sprite("sprites/archer.png")

        # Questgeber (villager that gives quests)
        sprites["q"] = self._load_sprite("sprites/villager_quest.png")

        # Knappe & evtl. weitere
        sprites["k"] = self._load_sprite("sprites/knappe.png")

        # Gruppen-Sprites
        for key, group in TILE_GROUPS.items():
            for code, path in group:
                sprites[code] = self._load_sprite(path)
        # zusätzliche Sprites: farbige Türen und Schlüssel, weiblicher Villager
        for col in ("green", "violet", "blue", "golden", "red"):
            sprites[f"locked_door_{col}"] = self._load_sprite(f"sprites/locked_door_{col}.png")
            sprites[f"key_{col}"] = self._load_sprite(f"sprites/key_{col}.png")
        sprites["v_female"] = self._load_sprite("sprites/villager2.png")
        return sprites

    def _load_sprite(self, path):
        try:
            if os.path.exists(path):
                img = pygame.image.load(path).convert_alpha()
                return pygame.transform.smoothscale(img, (self.tilesize, self.tilesize))
        except Exception as e:
            print(f"[Warnung] Sprite fehlgeschlagen {path}: {e}")
        # Fallback
        surf = pygame.Surface((self.tilesize, self.tilesize), pygame.SRCALPHA)
        surf.fill((200, 0, 0, 60))
        return surf

    # -----------------------------
    # Fenster/Panel
    # -----------------------------
    def _recalc_window(self):
        self.panel_w = 380
        self.win_w = self.grid_w * self.tilesize + self.panel_w + 2 * MARGIN
        self.win_h = max(self.grid_h * self.tilesize + 2 * MARGIN, 620)

    # -----------------------------
    # Tiles setzen
    # -----------------------------
    def set_tile_at_mouse(self, code, right_click=False):
        mx, my = pygame.mouse.get_pos()
        gx = (mx - MARGIN) // self.tilesize
        gy = (my - MARGIN) // self.tilesize
        if not (0 <= gx < self.grid_w and 0 <= gy < self.grid_h):
            return

        if right_click:
            # Entferne ggf. gespeicherte Settings für diese Koordinate
            key = f"{gx},{gy}"
            self.level[gy][gx] = "w"
            self.colors.pop(key, None)
            self.villagers.pop(key, None)
            return

        aktueller_code = self.level[gy][gx]

        # Sichtbarkeit toggeln, wenn gleicher Typ (Großbuchstabe = sichtbar markiert)
        if aktueller_code.lower() == code.lower():
            if aktueller_code.isupper():
                self.level[gy][gx] = aktueller_code.lower()
            else:
                # Nur eine sichtbare Markierung je Typ
                for y in range(self.grid_h):
                    for x in range(self.grid_w):
                        if self.level[y][x].lower() == code.lower():
                            self.level[y][x] = self.level[y][x].lower()
                self.level[gy][gx] = code.upper()
            return

        # Max. ein Held und max. ein Knappe
        if code.lower() in ("p", "k"):
            for row in self.level:
                for c in row:
                    if c.lower() == code.lower():
                        print(f"[Hinweis] Es darf nur einen '{code.lower()}' geben!")
                        return

        self.level[gy][gx] = code

    # Falls wir eine Tür, einen Schlüssel oder einen Villager/Questgeber setzen,
    # dann speichere die gewählte Farbe / das gewählte Geschlecht in den settings.
        key = f"{gx},{gy}"
        if code.lower() == "d":
            # Türfarbe: falls keine ausgewählt, entferne Eintrag (spawn benutzt default)
            if self.selected_door_color:
                self.colors[key] = self.selected_door_color
            else:
                self.colors.pop(key, None)

        elif code.lower() == "s":
            # Schlüsselfarbe: falls keine ausgewählt, benutze default 'green'
            color = self.selected_key_color or "green"
            self.colors[key] = color

        elif code.lower() == "v" or code.lower() == "q":
            # Villager or Questgeber: store gender for spawn-time
            self.villagers[key] = "female" if self.selected_villager_weiblich else "male"

    # -----------------------------
    # Rendering
    # -----------------------------
    def draw(self):
        self.screen.fill((15, 15, 15))
        self._draw_grid()
        self._draw_panel()
        pygame.display.flip()

    def _draw_grid(self):
        for y in range(self.grid_h):
            for x in range(self.grid_w):
                gx, gy = MARGIN + x * self.tilesize, MARGIN + y * self.tilesize
                rect = pygame.Rect(gx, gy, self.tilesize, self.tilesize)
                code = self.level[y][x]

                # Basisgras
                self.screen.blit(self.sprites.get("w"), (gx, gy))

                # Tile (unterstützt farbige Türen/Schlüssel und weibliche Villager)
                if code != "w":
                    low = code.lower()
                    key_coord = f"{x},{y}"
                    sprite = None
                    if low == "d":
                        col = self.colors.get(key_coord)
                        if col:
                            sprite = self.sprites.get(f"locked_door_{col}")
                        else:
                            sprite = self.sprites.get("d")
                    elif low == "s":
                        col = self.colors.get(key_coord) or "green"
                        sprite = self.sprites.get(f"key_{col}")
                    elif low == "v":
                        gender = self.villagers.get(key_coord)
                        if isinstance(gender, str) and gender.lower() in ("female", "weiblich", "w"):
                            sprite = self.sprites.get("v_female")
                        else:
                            sprite = self.sprites.get("v")
                    else:
                        sprite = self.sprites.get(low)

                    if sprite:
                        self.screen.blit(sprite, (gx, gy))
                    else:
                        pygame.draw.rect(self.screen, FALLBACK_COLORS.get(code.lower(), (80, 80, 80)), rect)

                # Sichtbarkeitsrahmen
                if code.isupper():
                    pygame.draw.rect(self.screen, (255, 0, 0), rect, 3)

                # Raster
                pygame.draw.rect(self.screen, (0, 0, 0), rect, 1)
                # Richtungsindikator (kleiner Pfeil) falls Orientierung gesetzt oder Tile drehbar
                key = f"{x},{y}"
                dir = self.orientations.get(key, None)
                if dir:
                    # einfache Pfeil- / Richtungsanzeige: Linie vom Zentrum nach dir
                    cx, cy = gx + self.tilesize // 2, gy + self.tilesize // 2
                    off = self.tilesize // 3
                    vecs = {"up": (0, -off), "right": (off, 0), "down": (0, off), "left": (-off, 0)}
                    dx, dy = vecs.get(dir, (0, off))
                    pygame.draw.line(self.screen, (255, 240, 0), (cx, cy), (cx + dx, cy + dy), 3)
                    # Pfeilspitze
                    pygame.draw.circle(self.screen, (255, 240, 0), (cx + dx, cy + dy), 4)

                # If a move-to victory target is configured, draw a red highlight around that tile
                try:
                    vic = self.level_settings.get('victory', {}) or {}
                    mv = vic.get('move_to') if isinstance(vic, dict) else None
                    if mv and isinstance(mv, dict) and mv.get('enabled'):
                        tx = int(mv.get('x', -999))
                        ty = int(mv.get('y', -999))
                        if tx == x and ty == y:
                            pygame.draw.rect(self.screen, (255, 0, 0), rect, 4)
                except Exception:
                    pass

    def _draw_panel(self):
        x0 = MARGIN + self.grid_w * self.tilesize + MARGIN
        y = MARGIN
        pygame.draw.rect(self.screen, (35, 35, 35), (x0 - MARGIN, 0, self.panel_w, self.win_h))

        self._text(self.big, "Level-Editor", (240, 240, 240), x0, y); y += 34
        self._text(self.font, f"Größe: {self.grid_w} x {self.grid_h}", (220, 220, 220), x0, y); y += 30

        # Aktuelles Tile
        self._text(self.font, "Aktuelles Tile:", (200, 200, 80), x0, y); y += 22
        # Sonderfälle: Tür mit Farbe, Schlüssel mit Farbe, weiblicher Villager
        sprite = None
        if self.selected_code == "d":
            if self.selected_door_color:
                sprite = self.sprites.get(f"locked_door_{self.selected_door_color}")
            else:
                sprite = self.sprites.get("d")
        elif self.selected_code == "s":
            kc = self.selected_key_color or "green"
            sprite = self.sprites.get(f"key_{kc}")
        elif self.selected_code == "v":
            if self.selected_villager_weiblich:
                sprite = self.sprites.get("v_female")
            else:
                sprite = self.sprites.get("v")
        if not sprite:
            sprite = self.sprites.get(self.selected_code)
        if sprite:
            preview = pygame.transform.smoothscale(sprite, (48, 48))
            self.screen.blit(preview, (x0, y))
        y += 60

        # Tile-Tabelle
        self._text(self.font, "Tiles:", (200, 200, 80), x0, y); y += 25
        for key, (code, path) in TILES.items():
            if key == "2":
                txt = f"[2]  →  't'/'m'/'b' (zyklisch)"
            elif key == "6":
                txt = f"[6]  →  'p'/'k' (toggle Held/Knappe)"
            elif key == "5":
                txt = f"[5]  →  'x'/'y' (Monster / Bogenschuetze - cycle)"
            else:
                txt = f"[{key}]  →  '{code}'"
            self._text(self.small, txt, (230, 230, 230), x0 + 10, y)
            y += 20
        y += 15

        # Privatisierung (Bonuspanel)
        self._text(self.font, "Privatisierung:", (200, 200, 80), x0, y); y += 25
        for k, v in self.privacy_flags.items():
            color = (180, 60, 60) if v else (100, 180, 100)
            self._text(self.small, f"{k}: {'privat' if v else 'öffentlich'}", color, x0, y)
            y += 18
        y += 10
        self._text(self.small, "F1=Privacy  F2=Einstellungen  F3=Sieg", (160, 160, 160), x0, y); y += 18
        self._text(self.small, "F4=Klassen  F5=Hilfe/Tipps", (160, 160, 160), x0, y); y += 18

    def _text(self, font, text, color, x, y):
        surf = font.render(text, True, color)
        self.screen.blit(surf, (x, y))

    def open_quest_dialog(self):
        """Öffnet einen kleinen Dialog, um am Mauszeiger einen Questgeber zu platzieren
        und die Quest-Parameter (modus, wuensche, anzahl) festzulegen.
        """
        # Mouse grid coord
        mx, my = pygame.mouse.get_pos()
        gx = (mx - MARGIN) // self.tilesize
        gy = (my - MARGIN) // self.tilesize
        if not (0 <= gx < self.grid_w and 0 <= gy < self.grid_h):
            return

        # Tkinter dialog
        root = tk.Tk(); root.title("Questgeber platzieren")
        frm = ttk.Frame(root, padding=10); frm.grid(row=0, column=0)

        ttk.Label(frm, text=f"Position: {gx},{gy}").grid(row=0, column=0, columnspan=2, sticky='w')
        ttk.Label(frm, text="Modus:").grid(row=1, column=0, sticky='w')
        modus_var = tk.StringVar(value='items')
        ttk.Radiobutton(frm, text='Items', variable=modus_var, value='items').grid(row=1, column=1, sticky='w')
        ttk.Radiobutton(frm, text='Rätsel', variable=modus_var, value='raetsel').grid(row=1, column=2, sticky='w')

        ttk.Label(frm, text="Wuensche (Komma-separiert, Namen):").grid(row=2, column=0, sticky='w')
        wishes_ent = ttk.Entry(frm, width=40)
        wishes_ent.grid(row=2, column=1, columnspan=2)

        ttk.Label(frm, text="Anzahl Items (optional):").grid(row=3, column=0, sticky='w')
        anz_ent = ttk.Entry(frm, width=10)
        anz_ent.grid(row=3, column=1, sticky='w')

        def ok():
            mode = modus_var.get()
            wishes = [w.strip() for w in wishes_ent.get().split(',') if w.strip()]
            anz = None
            try:
                anz = int(anz_ent.get())
            except Exception:
                anz = None
            key = f"{gx},{gy}"
            self.quests[key] = {"modus": mode}
            if wishes:
                self.quests[key]["wuensche"] = wishes
            if anz is not None:
                self.quests[key]["anzahl"] = anz
            # set tile to 'q'
            self.level[gy][gx] = 'q'
            root.destroy()

        def cancel():
            root.destroy()

        ttk.Button(frm, text="OK", command=ok).grid(row=4, column=1, pady=8)
        ttk.Button(frm, text="Abbrechen", command=cancel).grid(row=4, column=2, pady=8)
        root.mainloop()

    # -----------------------------
    # Privatisierung (F1)
    # -----------------------------
    def open_privacy_menu(self):
        root = tk.Tk()
        root.title("Privatisierung pro Klasse")

        frame = ttk.Frame(root, padding=10)
        frame.grid(row=0, column=0)

        ttk.Label(frame, text="Privatisierung pro Klasse:", font=("Consolas", 12, "bold")).grid(row=0, column=0, sticky="w")

        vars_by_class = {}
        for i, (klasse, val) in enumerate(self.privacy_flags.items(), start=1):
            var = tk.BooleanVar(value=val)
            chk = ttk.Checkbutton(frame, text=klasse, variable=var)
            chk.grid(row=i, column=0, sticky="w")
            vars_by_class[klasse] = var

        def speichern():
            for klasse, var in vars_by_class.items():
                self.privacy_flags[klasse] = var.get()
            root.destroy()

        ttk.Button(frame, text="OK", command=speichern).grid(row=len(vars_by_class) + 1, column=0, pady=10)
        root.mainloop()

    # -----------------------------
    # Allgemeine Level-Einstellungen (F2)
    # -----------------------------
    def open_settings_dialog(self):
        """Öffnet einen Dialog zum Einstellen von Level-weiten Parametern:
        initial_gold, quest_max_kosten, quest_mode, quest_items_needed
        """
        root = tk.Tk(); root.title("Level-Einstellungen")
        frm = ttk.Frame(root, padding=10); frm.grid(row=0, column=0)

        ttk.Label(frm, text="Start-Gold:").grid(row=0, column=0, sticky='w')
        gold_var = tk.StringVar(value=str(self.level_settings.get('initial_gold', 0)))
        ttk.Entry(frm, textvariable=gold_var, width=12).grid(row=0, column=1, sticky='w')

        ttk.Label(frm, text="Quest-Modus:").grid(row=1, column=0, sticky='w')
        qm_var = tk.StringVar(value=str(self.level_settings.get('quest_mode', 'items')))
        ttk.Radiobutton(frm, text='items', variable=qm_var, value='items').grid(row=1, column=1, sticky='w')
        ttk.Radiobutton(frm, text='raetsel', variable=qm_var, value='raetsel').grid(row=1, column=2, sticky='w')

        ttk.Label(frm, text="Quest max Kosten:").grid(row=2, column=0, sticky='w')
        qmk_var = tk.StringVar(value=str(self.level_settings.get('quest_max_kosten', 0)))
        ttk.Entry(frm, textvariable=qmk_var, width=12).grid(row=2, column=1, sticky='w')

        ttk.Label(frm, text="Quest Items benötigt:").grid(row=3, column=0, sticky='w')
        qin_var = tk.StringVar(value=str(self.level_settings.get('quest_items_needed', 1)))
        ttk.Entry(frm, textvariable=qin_var, width=12).grid(row=3, column=1, sticky='w')

        # Randomization options for doors/keys
        ttk.Label(frm, text="Zufallsoptionen (Doors/Keys):", font=("Consolas", 10, "bold")).grid(row=13, column=0, sticky='w', pady=(8,0))
        random_doors_var = tk.BooleanVar(value=bool(self.level_settings.get('random_door', False)))
        random_keys_var = tk.BooleanVar(value=bool(self.level_settings.get('random_keys', False)))
        chk_rand_doors = ttk.Checkbutton(frm, text="Zufällige Türfarben (random_door)", variable=random_doors_var)
        chk_rand_doors.grid(row=14, column=0, columnspan=2, sticky='w')
        chk_rand_keys = ttk.Checkbutton(frm, text="Zufällige Schlüsselfarben (random_keys)", variable=random_keys_var)
        chk_rand_keys.grid(row=15, column=0, columnspan=2, sticky='w')

        def ok():
            try:
                self.level_settings['initial_gold'] = int(gold_var.get())
            except Exception:
                self.level_settings['initial_gold'] = 0
            self.level_settings['quest_mode'] = qm_var.get()
            try:
                self.level_settings['quest_max_kosten'] = int(qmk_var.get())
            except Exception:
                self.level_settings['quest_max_kosten'] = 0
            try:
                self.level_settings['quest_items_needed'] = int(qin_var.get())
            except Exception:
                self.level_settings['quest_items_needed'] = 1
            # persist randomization flags
            try:
                self.level_settings['random_door'] = bool(random_doors_var.get())
            except Exception:
                pass
            try:
                self.level_settings['random_keys'] = bool(random_keys_var.get())
            except Exception:
                pass
            root.destroy()

        def cancel():
            root.destroy()

        ttk.Button(frm, text='OK', command=ok).grid(row=4, column=1, pady=8)
        ttk.Button(frm, text='Abbrechen', command=cancel).grid(row=4, column=2, pady=8)
        root.mainloop()

    # -----------------------------
    # Victory conditions (F3)
    # -----------------------------
    def open_victory_dialog(self):
        """Dialog (F3) to configure multiple victory conditions.
        - Collect all hearts (boolean)
        - Move to coordinate (boolean + x,y)
        - Classes implemented (boolean)
        """
        # Prefill with existing values
        vic = self.level_settings.get('victory', {}) or {}
        collect_def = bool(vic.get('collect_hearts', True))
        move_def = vic.get('move_to') or {}
        move_enabled = bool(move_def.get('enabled', False)) if isinstance(move_def, dict) else False
        move_x = str(move_def.get('x', 0)) if isinstance(move_def, dict) else '0'
        move_y = str(move_def.get('y', 0)) if isinstance(move_def, dict) else '0'
        classes_def = bool(vic.get('classes_present', False))
        rebuild_def = bool(vic.get('rebuild_mode', False))

        root = tk.Tk(); root.title("Siegbedingungen (F3)")
        frm = ttk.Frame(root, padding=10); frm.grid(row=0, column=0)

        ttk.Label(frm, text="Siegbedingungen:", font=("Consolas", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky='w')

        collect_var = tk.BooleanVar(value=collect_def)
        tk.Checkbutton(frm, text="Alle Herzen sammeln (Standard)", variable=collect_var).grid(row=1, column=0, columnspan=3, sticky='w', pady=(6,2))

        move_var = tk.BooleanVar(value=move_enabled)
        tk.Checkbutton(frm, text="Zum Zielfeld bewegen (x,y):", variable=move_var).grid(row=2, column=0, sticky='w')
        x_ent = ttk.Entry(frm, width=6)
        x_ent.insert(0, move_x)
        x_ent.grid(row=2, column=1, sticky='w')
        y_ent = ttk.Entry(frm, width=6)
        y_ent.insert(0, move_y)
        y_ent.grid(row=2, column=2, sticky='w')

        ttk.Label(frm, text="Tipp: Klicke das Level-Feld an und öffne F3, um Koordinaten vorzufüllen.").grid(row=3, column=0, columnspan=3, sticky='w', pady=(4,6))

        classes_var = tk.BooleanVar(value=classes_def)
        tk.Checkbutton(frm, text="Alle im Level verwendeten Klassen implementiert (Schülerklassen)", variable=classes_var).grid(row=4, column=0, columnspan=3, sticky='w', pady=(6,2))

        rebuild_var = tk.BooleanVar(value=rebuild_def)
        tk.Checkbutton(frm, text="Level nachbauen (Schüler müssen Objekte selbst erzeugen)", variable=rebuild_var).grid(row=5, column=0, columnspan=3, sticky='w', pady=(6,2))
        
        ttk.Label(frm, text="Hinweis: 'Level nachbauen' ist inkompatibel mit 'Bewegen' und 'Herzen sammeln'.", font=("Consolas", 9)).grid(row=6, column=0, columnspan=3, sticky='w', pady=(2,6))

        def ok():
            try:
                v = {}
                rebuild_enabled = bool(rebuild_var.get())
                
                # Wenn rebuild_mode aktiv ist, deaktiviere inkompatible Optionen
                if rebuild_enabled:
                    v['rebuild_mode'] = True
                    v['collect_hearts'] = False
                    v['move_to'] = None
                else:
                    v['rebuild_mode'] = False
                    v['collect_hearts'] = bool(collect_var.get())
                    if move_var.get():
                        try:
                            vx = int(x_ent.get())
                            vy = int(y_ent.get())
                            v['move_to'] = {'enabled': True, 'x': vx, 'y': vy}
                        except Exception:
                            v['move_to'] = {'enabled': False}
                    else:
                        v['move_to'] = None
                
                v['classes_present'] = bool(classes_var.get())
                self.level_settings['victory'] = v
            except Exception:
                pass
            root.destroy()

        def cancel():
            root.destroy()

        ttk.Button(frm, text='OK', command=ok).grid(row=7, column=1, pady=8)
        ttk.Button(frm, text='Abbrechen', command=cancel).grid(row=7, column=2, pady=8)
        root.mainloop()

    # -----------------------------
    # Hilfe / Tipps bearbeiten (F5)
    # -----------------------------
    def open_hints_dialog(self):
        """Dialog (F5) zum Bearbeiten der Level-Hilfe: Phase-Text, Tipps und Codebeispiel."""
        root = tk.Tk()
        root.title("Hilfe / Tipps bearbeiten (F5)")
        root.geometry("680x560")
        root.configure(bg="#f0f0f0")

        frm = ttk.Frame(root, padding=12)
        frm.pack(fill='both', expand=True)
        frm.columnconfigure(0, weight=1)
        frm.rowconfigure(3, weight=2)
        frm.rowconfigure(5, weight=1)

        # ── Phase-Text ──────────────────────────────────────────────────────
        ttk.Label(frm, text="Phase-Text (leer \u2192 automatisch aus Siegbedingung):").grid(
            row=0, column=0, sticky='w', pady=(0, 2))
        phase_var = tk.StringVar(value=self.hints.get('phase', ''))
        ttk.Entry(frm, textvariable=phase_var, width=70).grid(
            row=1, column=0, sticky='ew', pady=(0, 14))

        # ── Tipps ────────────────────────────────────────────────────────────
        tip_header = ttk.Frame(frm)
        tip_header.grid(row=2, column=0, sticky='ew')
        ttk.Label(tip_header, text="Tipps (pro Zeile ein Tipp \u2013 wird als Bulletpoint angezeigt):").pack(side='left')

        def add_tipp():
            tips_text.insert('end', '\n')
            tips_text.see('end')
            tips_text.focus_set()

        ttk.Button(tip_header, text="\u2013 Tipp hinzuf\u00fcgen", command=add_tipp).pack(side='right')

        tips_frame = ttk.Frame(frm)
        tips_frame.grid(row=3, column=0, sticky='nsew', pady=(4, 0))
        tips_frame.columnconfigure(0, weight=1)
        tips_frame.rowconfigure(0, weight=1)
        tips_text = tk.Text(tips_frame, height=8, font=("Consolas", 11), wrap='word',
                            relief='solid', borderwidth=1)
        tips_text.grid(row=0, column=0, sticky='nsew')
        tips_sb = ttk.Scrollbar(tips_frame, command=tips_text.yview)
        tips_sb.grid(row=0, column=1, sticky='ns')
        tips_text['yscrollcommand'] = tips_sb.set
        existing_tips = self.hints.get('text', [])
        tips_text.insert('1.0', '\n'.join(existing_tips))

        # ── Codebeispiel ─────────────────────────────────────────────────────
        ttk.Label(frm, text="Codebeispiel (pro Zeile eine Code-Zeile):").grid(
            row=4, column=0, sticky='w', pady=(12, 4))
        code_frame = ttk.Frame(frm)
        code_frame.grid(row=5, column=0, sticky='nsew')
        code_frame.columnconfigure(0, weight=1)
        code_frame.rowconfigure(0, weight=1)
        code_text = tk.Text(code_frame, height=6, font=("Consolas", 11), wrap='none',
                            relief='solid', borderwidth=1)
        code_text.grid(row=0, column=0, sticky='nsew')
        code_sb_y = ttk.Scrollbar(code_frame, command=code_text.yview)
        code_sb_y.grid(row=0, column=1, sticky='ns')
        code_sb_x = ttk.Scrollbar(code_frame, orient='horizontal', command=code_text.xview)
        code_sb_x.grid(row=1, column=0, sticky='ew')
        code_text['yscrollcommand'] = code_sb_y.set
        code_text['xscrollcommand'] = code_sb_x.set
        existing_code = self.hints.get('code', [])
        code_text.insert('1.0', '\n'.join(existing_code))

        # ── Buttons ──────────────────────────────────────────────────────────
        def ok():
            phase = phase_var.get().strip()
            tips = [t.strip() for t in tips_text.get('1.0', 'end').splitlines() if t.strip()]
            code = [c.rstrip() for c in code_text.get('1.0', 'end').splitlines() if c.rstrip()]

            # Preserve all existing hint flags; only update the three editable fields
            if phase:
                self.hints['phase'] = phase
            else:
                self.hints.pop('phase', None)
            if tips:
                self.hints['text'] = tips
            else:
                self.hints.pop('text', None)
            if code:
                self.hints['code'] = code
            else:
                self.hints.pop('code', None)

            root.destroy()

        def cancel():
            root.destroy()

        btn_frm = ttk.Frame(frm)
        btn_frm.grid(row=6, column=0, pady=10, sticky='e')
        ttk.Button(btn_frm, text="OK", command=ok).pack(side='left', padx=6)
        ttk.Button(btn_frm, text="Abbrechen", command=cancel).pack(side='left')
        root.mainloop()

    # -----------------------------
    # Class Requirements (F4)
    # -----------------------------
    def open_class_requirements_dialog(self):
        """Dialog (F4) to configure per-class requirements for student implementation.
        Each class gets:
        - List of required methods (checkboxes + text field)
        - List of required attributes (checkboxes + text field)
        - Inheritance dropdown (which framework class this should inherit from)
        - Toggle: Use student class for this entity type
        """
        # Define all classes that can be implemented by students (Code renamed to Zettel)
        # Spielobjekt and Charakter are abstract base classes
        CLASSES = ["Spielobjekt", "Charakter", "Held", "Herz", "Tuer", "Tor", "Hindernis", "Knappe", "Monster", "Bogenschuetze", "Schluessel", "Zettel", "Villager", "Inventar", "Gegenstand"]
        
        # Define core attributes as checkboxes (only x, y, typ, richtung, name, weiblich)
        CORE_ATTRIBUTES = {
            "Spielobjekt": ["x", "y", "typ"],
            "Charakter": ["x", "y", "typ", "richtung", "name"],
            "Held": ["x", "y", "richtung", "typ", "name", "weiblich", "rucksack"],
            "Knappe": ["x", "y", "richtung", "name", "rucksack"],
            "Monster": ["x", "y", "richtung", "name"],
            "Bogenschuetze": ["x", "y", "richtung", "name"],
            "Herz": ["x", "y"],
            "Tuer": ["x", "y"],
            "Tor": ["x", "y"],
            "Schluessel": ["x", "y"],
            "Hindernis": ["x", "y", "typ"],
            "Zettel": ["x", "y", "typ", "spruch"],
            "Villager": ["x", "y", "name"],
            "Inventar": ["items", "kapazitaet", "gold"],
            "Gegenstand": ["art", "typ", "im_inventar"],
        }
        
        # Define standard methods as checkboxes
        STANDARD_METHODS = {
            "Spielobjekt": ["get_x", "get_y", "get_typ", "ist_passierbar"],
            "Charakter": ["set_position", "get_x", "get_y", "geh", "links", "rechts", "zurueck", 
                         "gib_objekt_vor_dir", "was_ist_vorn", "was_ist_links", "was_ist_rechts",
                         "ist_auf_herz", "herzen_vor_mir", "set_richtung", "get_richtung", 
                         "get_name", "set_name", "ist_passierbar"],
            "Held": ["set_position", "get_x", "get_y", "geh", "links", "rechts", "zurueck", 
                    "gib_objekt_vor_dir", "was_ist_vorn", "was_ist_links", "was_ist_rechts",
                    "ist_auf_herz", "herzen_vor_mir", "set_richtung", "get_richtung", 
                    "get_name", "set_name", "nimm_herz", "spruch_lesen", "spruch_sagen", 
                    "bediene_tor", "verwende_schluessel", "ist_passierbar"],
            "Knappe": ["set_position", "get_x", "get_y", "geh", "links", "rechts", "zurueck",
                      "gib_objekt_vor_dir", "was_ist_vorn", "was_ist_links", "was_ist_rechts",
                      "ist_auf_herz", "herzen_vor_mir", "set_richtung", "get_richtung",
                      "get_name", "set_name", "nimm_herz", "spruch_lesen", "spruch_sagen",
                      "bediene_tor", "verwende_schluessel", "ist_passierbar"],
            "Monster": ["set_position", "get_x", "get_y", "geh", "links", "rechts", "zurueck",
                       "gib_objekt_vor_dir", "was_ist_vorn", "was_ist_links", "was_ist_rechts",
                       "ist_auf_herz", "herzen_vor_mir", "set_richtung", "get_richtung",
                       "get_name", "set_name", "angriff", "ist_passierbar"],
            "Bogenschuetze": ["set_position", "get_x", "get_y", "geh", "links", "rechts", "zurueck",
                             "gib_objekt_vor_dir", "was_ist_vorn", "was_ist_links", "was_ist_rechts",
                             "ist_auf_herz", "herzen_vor_mir", "set_richtung", "get_richtung",
                             "get_name", "set_name", "angriff", "ist_passierbar"],
            "Herz": ["set_position", "get_x", "get_y", "ist_passierbar"],
            "Tuer": ["set_position", "get_x", "get_y", "ist_passierbar"],
            "Tor": ["set_position", "get_x", "get_y", "ist_passierbar"],
            "Schluessel": ["set_position", "get_x", "get_y", "ist_passierbar"],
            "Hindernis": ["set_position", "get_x", "get_y", "get_typ", "ist_passierbar"],
            "Zettel": ["set_position", "get_x", "get_y", "get_typ", "get_spruch", "set_spruch", "ist_passierbar"],
            "Villager": ["set_position", "get_x", "get_y", "geh", "links", "rechts", "zurueck",
                        "gib_objekt_vor_dir", "was_ist_vorn", "was_ist_links", "was_ist_rechts",
                        "ist_auf_herz", "herzen_vor_mir", "set_richtung", "get_richtung",
                        "get_name", "set_name", "ist_passierbar"],
            "Inventar": ["item_hinzufuegen", "hat_item", "anzahl_items", "gib_item_nummer", 
                        "gib_kapazitaet", "gib_gold", "gold_sammeln", "ist_voll"],
            "Gegenstand": ["sammeln"],
        }
        
        # Define inheritance options per class (framework base classes)
        INHERITANCE_OPTIONS = {
            "Spielobjekt": ["None"],  # Abstract class, no inheritance
            "Charakter": ["Spielobjekt", "None"],  # Inherits from Spielobjekt
            "Held": ["Spielobjekt", "Charakter", "Tuer", "Tor", "Monster", "None"],
            "Knappe": ["Spielobjekt", "Charakter", "Tuer", "Tor", "Monster", "None"],
            "Monster": ["Spielobjekt", "Charakter", "Tuer", "Tor", "None"],
            "Bogenschuetze": ["Spielobjekt", "Charakter", "Monster", "Tuer", "Tor", "None"],
            "Herz": ["Spielobjekt", "Gegenstand", "None"],
            "Tuer": ["Spielobjekt", "None"],
            "Tor": ["Spielobjekt", "None"],
            "Schluessel": ["Spielobjekt", "Gegenstand", "None"],
            "Hindernis": ["Spielobjekt", "None"],
            "Zettel": ["Spielobjekt", "Gegenstand", "None"],
            "Inventar": ["None"],
            "Gegenstand": ["None"],
            "Villager": ["Spielobjekt", "Charakter", "None"],
        }
        
        root = tk.Tk()
        root.title("Schülerklassen-Anforderungen (F4)")
        root.geometry("700x600")
        
        # Create notebook with tabs
        notebook = ttk.Notebook(root)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Store UI variables for each class
        class_vars = {}
        
        for class_name in CLASSES:
            # Create a frame for this class tab
            tab_frame = ttk.Frame(notebook)
            notebook.add(tab_frame, text=class_name)
            
            # Create scrollable frame for content
            canvas = tk.Canvas(tab_frame)
            scrollbar = ttk.Scrollbar(tab_frame, orient="vertical", command=canvas.yview)
            scrollable_frame = ttk.Frame(canvas)
            
            scrollable_frame.bind(
                "<Configure>",
                lambda e, c=canvas: c.configure(scrollregion=c.bbox("all"))
            )
            
            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            
            # Get existing config or use defaults
            existing = self.class_requirements.get(class_name, {})
            
            # Special case for Held: Two mutually exclusive checkboxes for source location
            load_schueler_var = None
            load_klassen_var = None
            check_implementation_var = None
            expects_set_level_var = None
            
            # Charakterklassen: Checkbox für "Level setzen" (ganz oben)
            CHARACTER_CLASSES = ["Charakter", "Held", "Knappe", "Monster", "Bogenschuetze", "Villager"]
            if class_name in CHARACTER_CLASSES:
                ttk.Label(scrollable_frame, text="Framework-Integration:", font=("Consolas", 10, "bold")).pack(anchor='w', pady=(10,2))
                expects_set_level_var = tk.BooleanVar(value=existing.get("expects_set_level", False))
                ttk.Checkbutton(scrollable_frame, text="Level setzen (set_level Methode)", variable=expects_set_level_var).pack(anchor='w', padx=10)
                ttk.Label(scrollable_frame, text="(Wenn aktiviert: Charakter hat 'level' Attribut und set_level(spielfeld) Methode,\n"
                                                "Framework ruft set_level nach Erzeugung auf)", 
                         font=("Consolas", 8)).pack(anchor='w', padx=10, pady=(0,5))
                ttk.Separator(scrollable_frame, orient='horizontal').pack(fill='x', pady=5)
            
            # Special handling for abstract/utility classes
            if class_name in ["Spielobjekt", "Charakter", "Inventar", "Gegenstand"]:
                if class_name in ["Spielobjekt", "Charakter"]:
                    label_text = f"{class_name} ist eine abstrakte Klasse:"
                    checkbox_text = "Prüfe, ob implementiert"
                    help_text = "(Wenn aktiviert: Prüft, ob Schüler diese Klasse selbst implementiert hat)"
                else:
                    label_text = f"{class_name} Validierung:"
                    checkbox_text = "Klasse prüfen"
                    help_text = "(Kommt nicht natürlich im Level vor - Checkbox aktivieren, um zu prüfen)"
                
                ttk.Label(scrollable_frame, text=label_text, font=("Consolas", 10, "bold")).pack(anchor='w', pady=(10,2))
                check_implementation_var = tk.BooleanVar(value=existing.get("check_implementation", False))
                ttk.Checkbutton(scrollable_frame, text=checkbox_text, variable=check_implementation_var).pack(anchor='w', padx=10)
                ttk.Label(scrollable_frame, text=help_text, 
                         font=("Consolas", 8)).pack(anchor='w', padx=10, pady=(0,5))
            
            if class_name == "Held":
                ttk.Label(scrollable_frame, text="Lade Held-Klasse aus:", font=("Consolas", 10, "bold")).pack(anchor='w', pady=(10,2))
                
                # Create variables first
                load_schueler_var = tk.BooleanVar(value=existing.get("load_from_schueler", False))
                load_klassen_var = tk.BooleanVar(value=existing.get("load_from_klassen", False))
                
                # Mutual exclusion callbacks - capture variables in closure properly
                def make_schueler_toggle(schueler_var, klassen_var):
                    def toggle():
                        if schueler_var.get():
                            klassen_var.set(False)
                    return toggle
                
                def make_klassen_toggle(schueler_var, klassen_var):
                    def toggle():
                        if klassen_var.get():
                            schueler_var.set(False)
                    return toggle
                
                ttk.Checkbutton(scrollable_frame, text="Aus schueler.py laden (alte Einzeldatei)", 
                              variable=load_schueler_var, 
                              command=make_schueler_toggle(load_schueler_var, load_klassen_var)).pack(anchor='w', padx=10)
                ttk.Checkbutton(scrollable_frame, text="Aus klassen/held.py laden (Unterordner)", 
                              variable=load_klassen_var, 
                              command=make_klassen_toggle(load_schueler_var, load_klassen_var)).pack(anchor='w', padx=10)
                ttk.Label(scrollable_frame, text="(Keine Checkbox = integrierte Framework-Klasse)", 
                         font=("Consolas", 8)).pack(anchor='w', padx=10, pady=(0,5))
            
            # Inheritance selection
            ttk.Label(scrollable_frame, text="Erbt von:", font=("Consolas", 10, "bold")).pack(anchor='w', pady=(10,2))
            inherits_var = tk.StringVar(value=existing.get("inherits", "None"))
            inherits_combo = ttk.Combobox(scrollable_frame, textvariable=inherits_var, 
                                        values=INHERITANCE_OPTIONS.get(class_name, ["None"]), 
                                        state="readonly", width=20)
            inherits_combo.pack(anchor='w', padx=10)
            
            # Required attributes with public/private distinction
            ttk.Label(scrollable_frame, text="Erforderliche Attribute:", font=("Consolas", 10, "bold")).pack(anchor='w', pady=(15,2))
            attr_vars = {}
            attr_private_vars = {}
            
            # Get existing attributes (legacy: list, new: dict with privacy info)
            existing_attrs = existing.get("attributes", [])
            existing_attrs_private = existing.get("attributes_private", {})
            
            # Legacy compatibility: if attributes is a list, convert to dict format
            if isinstance(existing_attrs, list):
                existing_attrs_dict = {attr: True for attr in existing_attrs}
            else:
                existing_attrs_dict = existing_attrs if isinstance(existing_attrs, dict) else {}
            
            # Core attributes as two checkboxes per attribute (public/private)
            ttk.Label(scrollable_frame, text="Kernattribute (wähle: vorhanden ODER privat):", 
                     font=("Consolas", 9)).pack(anchor='w', padx=20, pady=(2,0))
            
            for attr in CORE_ATTRIBUTES.get(class_name, []):
                attr_frame = ttk.Frame(scrollable_frame)
                attr_frame.pack(anchor='w', padx=30, pady=2)
                
                ttk.Label(attr_frame, text=f"{attr}:", width=15).pack(side='left')
                
                # Check if this attribute is required (public or private)
                is_required = attr in existing_attrs_dict or existing_attrs_private.get(attr, False)
                is_private = existing_attrs_private.get(attr, False)
                
                public_var = tk.BooleanVar(value=(is_required and not is_private))
                private_var = tk.BooleanVar(value=is_private)
                
                # Mutual exclusion between public and private
                def make_public_toggle(pub_var, priv_var):
                    def toggle():
                        if pub_var.get():
                            priv_var.set(False)
                    return toggle
                
                def make_private_toggle(pub_var, priv_var):
                    def toggle():
                        if priv_var.get():
                            pub_var.set(False)
                    return toggle
                
                ttk.Checkbutton(attr_frame, text="vorhanden", variable=public_var,
                              command=make_public_toggle(public_var, private_var)).pack(side='left', padx=5)
                ttk.Checkbutton(attr_frame, text="privat", variable=private_var,
                              command=make_private_toggle(public_var, private_var)).pack(side='left', padx=5)
                
                attr_vars[attr] = public_var
                attr_private_vars[attr] = private_var
            
            # Additional public attributes
            ttk.Label(scrollable_frame, text="Weitere öffentliche Attribute (kommagetrennt):", 
                     font=("Consolas", 9)).pack(anchor='w', padx=20, pady=(10,0))
            core_attrs = set(CORE_ATTRIBUTES.get(class_name, []))
            extra_public_attrs = [a for a in existing_attrs_dict.keys() if a not in core_attrs and not existing_attrs_private.get(a, False)]
            extra_public_attrs_var = tk.StringVar(value=", ".join(extra_public_attrs))
            extra_public_attrs_entry = ttk.Entry(scrollable_frame, textvariable=extra_public_attrs_var, width=40)
            extra_public_attrs_entry.pack(anchor='w', padx=20, pady=(2,5))
            
            # Additional private attributes
            ttk.Label(scrollable_frame, text="Weitere private Attribute (kommagetrennt):", 
                     font=("Consolas", 9)).pack(anchor='w', padx=20, pady=(5,0))
            extra_private_attrs = [a for a in existing_attrs_private.keys() if a not in core_attrs and existing_attrs_private.get(a, False)]
            extra_private_attrs_var = tk.StringVar(value=", ".join(extra_private_attrs))
            extra_private_attrs_entry = ttk.Entry(scrollable_frame, textvariable=extra_private_attrs_var, width=40)
            extra_private_attrs_entry.pack(anchor='w', padx=20, pady=(2,5))
            
            # Required methods with public/private distinction
            ttk.Label(scrollable_frame, text="Erforderliche Methoden:", font=("Consolas", 10, "bold")).pack(anchor='w', pady=(15,2))
            method_vars = {}
            method_private_vars = {}
            
            # Get existing methods (legacy: list, new: dict with privacy info)
            existing_methods = existing.get("methods", [])
            existing_methods_private = existing.get("methods_private", {})
            
            # Legacy compatibility: if methods is a list, convert to dict format
            if isinstance(existing_methods, list):
                existing_methods_dict = {method: True for method in existing_methods}
            else:
                existing_methods_dict = existing_methods if isinstance(existing_methods, dict) else {}
            
            # Standard methods as two checkboxes per method (public/private)
            ttk.Label(scrollable_frame, text="Standardmethoden (wähle: vorhanden ODER privat):", 
                     font=("Consolas", 9)).pack(anchor='w', padx=20, pady=(2,0))
            
            for method in STANDARD_METHODS.get(class_name, []):
                method_frame = ttk.Frame(scrollable_frame)
                method_frame.pack(anchor='w', padx=30, pady=1)
                
                ttk.Label(method_frame, text=f"{method}:", width=25).pack(side='left')
                
                # Check if this method is required (public or private)
                is_required = method in existing_methods_dict or existing_methods_private.get(method, False)
                is_private = existing_methods_private.get(method, False)
                
                public_var = tk.BooleanVar(value=(is_required and not is_private))
                private_var = tk.BooleanVar(value=is_private)
                
                # Mutual exclusion between public and private
                def make_method_public_toggle(pub_var, priv_var):
                    def toggle():
                        if pub_var.get():
                            priv_var.set(False)
                    return toggle
                
                def make_method_private_toggle(pub_var, priv_var):
                    def toggle():
                        if priv_var.get():
                            pub_var.set(False)
                    return toggle
                
                ttk.Checkbutton(method_frame, text="vorhanden", variable=public_var,
                              command=make_method_public_toggle(public_var, private_var)).pack(side='left', padx=5)
                ttk.Checkbutton(method_frame, text="privat", variable=private_var,
                              command=make_method_private_toggle(public_var, private_var)).pack(side='left', padx=5)
                
                method_vars[method] = public_var
                method_private_vars[method] = private_var
            
            # Additional public methods
            ttk.Label(scrollable_frame, text="Weitere öffentliche Methoden (kommagetrennt):", 
                     font=("Consolas", 9)).pack(anchor='w', padx=20, pady=(10,0))
            standard_methods = set(STANDARD_METHODS.get(class_name, []))
            extra_public_methods = [m for m in existing_methods_dict.keys() if m not in standard_methods and not existing_methods_private.get(m, False)]
            extra_public_methods_var = tk.StringVar(value=", ".join(extra_public_methods))
            extra_public_methods_entry = ttk.Entry(scrollable_frame, textvariable=extra_public_methods_var, width=40)
            extra_public_methods_entry.pack(anchor='w', padx=20, pady=(2,5))
            
            # Additional private methods
            ttk.Label(scrollable_frame, text="Weitere private Methoden (kommagetrennt):", 
                     font=("Consolas", 9)).pack(anchor='w', padx=20, pady=(5,0))
            extra_private_methods = [m for m in existing_methods_private.keys() if m not in standard_methods and existing_methods_private.get(m, False)]
            extra_private_methods_var = tk.StringVar(value=", ".join(extra_private_methods))
            extra_private_methods_entry = ttk.Entry(scrollable_frame, textvariable=extra_private_methods_var, width=40)
            extra_private_methods_entry.pack(anchor='w', padx=20, pady=(2,5))
            
            # Store all variables for this class
            class_vars[class_name] = {
                "inherits": inherits_var,
                "methods": method_vars,
                "methods_private": method_private_vars,
                "attributes": attr_vars,
                "attributes_private": attr_private_vars,
                "extra_public_methods": extra_public_methods_var,
                "extra_private_methods": extra_private_methods_var,
                "extra_public_attributes": extra_public_attrs_var,
                "extra_private_attributes": extra_private_attrs_var,
                "load_from_schueler": load_schueler_var,
                "load_from_klassen": load_klassen_var,
                "check_implementation": check_implementation_var,
                "expects_set_level": expects_set_level_var
            }
        
        # OK and Cancel buttons at bottom
        button_frame = ttk.Frame(root)
        button_frame.pack(side='bottom', pady=10)
        
        def save_and_close():
            # Collect all configurations
            new_requirements = {}
            for class_name, vars_dict in class_vars.items():
                config = {}
                config["inherits"] = vars_dict["inherits"].get()
                
                # Special handling for Held class source location
                if class_name == "Held" and vars_dict["load_from_schueler"] and vars_dict["load_from_klassen"]:
                    config["load_from_schueler"] = vars_dict["load_from_schueler"].get()
                    config["load_from_klassen"] = vars_dict["load_from_klassen"].get()
                
                # Collect public methods (selected checkboxes)
                public_methods = [m for m, v in vars_dict["methods"].items() if v.get()]
                
                # Add extra public methods from text field
                extra_public_methods_str = vars_dict["extra_public_methods"].get().strip()
                if extra_public_methods_str:
                    extra_public = [m.strip() for m in extra_public_methods_str.split(",") if m.strip()]
                    public_methods.extend(extra_public)
                
                # Collect private methods (selected checkboxes)
                private_methods = {m: True for m, v in vars_dict["methods_private"].items() if v.get()}
                
                # Add extra private methods from text field
                extra_private_methods_str = vars_dict["extra_private_methods"].get().strip()
                if extra_private_methods_str:
                    extra_private = [m.strip() for m in extra_private_methods_str.split(",") if m.strip()]
                    for m in extra_private:
                        private_methods[m] = True
                
                # Store methods (keep list for backwards compatibility, add privacy dict)
                config["methods"] = public_methods
                if private_methods:
                    config["methods_private"] = private_methods
                
                # Collect public attributes (selected checkboxes)
                public_attrs = [a for a, v in vars_dict["attributes"].items() if v.get()]
                
                # Add extra public attributes from text field
                extra_public_attrs_str = vars_dict["extra_public_attributes"].get().strip()
                if extra_public_attrs_str:
                    extra_public = [a.strip() for a in extra_public_attrs_str.split(",") if a.strip()]
                    public_attrs.extend(extra_public)
                
                # Collect private attributes (selected checkboxes)
                private_attrs = {a: True for a, v in vars_dict["attributes_private"].items() if v.get()}
                
                # Add extra private attributes from text field
                extra_private_attrs_str = vars_dict["extra_private_attributes"].get().strip()
                if extra_private_attrs_str:
                    extra_private = [a.strip() for a in extra_private_attrs_str.split(",") if a.strip()]
                    for a in extra_private:
                        private_attrs[a] = True
                
                # Store attributes (keep list for backwards compatibility, add privacy dict)
                config["attributes"] = public_attrs
                if private_attrs:
                    config["attributes_private"] = private_attrs
                
                # Store check_implementation flag for abstract/utility classes
                if class_name in ["Spielobjekt", "Charakter", "Inventar", "Gegenstand"] and vars_dict.get("check_implementation"):
                    config["check_implementation"] = vars_dict["check_implementation"].get()
                
                # Store expects_set_level flag for character classes
                CHARACTER_CLASSES = ["Charakter", "Held", "Knappe", "Monster", "Bogenschuetze", "Villager"]
                if class_name in CHARACTER_CLASSES and vars_dict.get("expects_set_level"):
                    config["expects_set_level"] = vars_dict["expects_set_level"].get()
                
                # Store if anything is configured
                if public_methods or private_methods or public_attrs or private_attrs or config["inherits"] != "None":
                    new_requirements[class_name] = config
                # For Held, also store if load flags are set
                elif class_name == "Held" and (config.get("load_from_schueler") or config.get("load_from_klassen")):
                    new_requirements[class_name] = config
                # For abstract classes, store if check_implementation is set
                elif class_name in ["Spielobjekt", "Charakter"] and config.get("check_implementation"):
                    new_requirements[class_name] = config
                # For character classes, store if expects_set_level is set
                elif class_name in CHARACTER_CLASSES and config.get("expects_set_level"):
                    new_requirements[class_name] = config
            
            self.class_requirements = new_requirements
            print(f"[Info] Klassen-Anforderungen gespeichert: {len(new_requirements)} Klassen konfiguriert")
            root.destroy()
        
        def cancel():
            root.destroy()
        
        ttk.Button(button_frame, text="OK", command=save_and_close).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Abbrechen", command=cancel).pack(side='left', padx=5)
        
        root.mainloop()

    # -----------------------------
    # JSON I/O
    # -----------------------------
    def from_json(self, data):
        if "tiles" not in data:
            raise ValueError("JSON enthält kein Feld 'tiles'.")
        tiles = data["tiles"]
        self.grid_h = len(tiles)
        self.grid_w = max(len(r) for r in tiles)
        self.level = [list(r.ljust(self.grid_w, "w")) for r in tiles]

        # Settings optional (Abwärtskompatibilität)
        if "settings" in data:
            # settings may contain both per-type dicts (e.g. {"Held": {"public": true}})
            # and scalar keys (initial_gold, quest_mode...). Be defensive and only
            # extract privacy info from dict entries. Support both old 'privat' and
            # current 'public' keys.
            self.privacy_flags = {}
            try:
                for k, v in data["settings"].items():
                    if isinstance(v, dict):
                        if 'privat' in v:
                            self.privacy_flags[k] = bool(v.get('privat', False))
                        elif 'public' in v:
                            # privacy flag stored as public: True/False -> invert
                            self.privacy_flags[k] = not bool(v.get('public', True))
                        else:
                            # no privacy info in this dict
                            continue
            except Exception:
                # defensive fallback: empty dict
                self.privacy_flags = {}

            # Ensure expected keys exist
        for k in ["Held", "Knappe", "Monster", "Herz", "Tuer", "Zettel", "Villager", "Hindernis", "Schluessel", "Bogenschuetze"]:
            self.privacy_flags.setdefault(k, False)
        # Lade Orientierungen, falls vorhanden (Format: {"x,y": "up"})
        settings = data.get("settings", {})
        self.orientations = settings.get("orientations", {})
        # Lade gespeicherte Tür-/Schlüssel-Farben (falls vorhanden)
        self.colors = settings.get("colors", {}) or {}
        # Lade Villager-Geschlechter
        self.villagers = settings.get("villagers", {}) or {}
        # Lade Quest-Konfigurationen
        self.quests = settings.get("quests", {}) or {}
        # Lade zusätzliche Level-Einstellungen (z.B. initial_gold, quest_max_kosten,...)
        for k in ("initial_gold", "quest_max_kosten", "quest_mode", "quest_items_needed"):
            if k in settings:
                self.level_settings[k] = settings.get(k)
        # Load randomization flags if present
        try:
            if 'random_door' in settings:
                self.level_settings['random_door'] = bool(settings.get('random_door', False))
        except Exception:
            pass
        try:
            if 'random_keys' in settings:
                self.level_settings['random_keys'] = bool(settings.get('random_keys', False))
        except Exception:
            pass

        # Load victory settings if present (backwards compatible: default to collect_hearts)
        try:
            vic = settings.get('victory')
            default_vic = {"collect_hearts": True, "move_to": None, "classes_present": False}
            # If level file contains an explicit victory dict, use it. Otherwise
            # overwrite any previous editor state with the default so that the
            # editor doesn't carry the last-loaded level's target into the new one.
            if isinstance(vic, dict):
                self.level_settings['victory'] = vic
            else:
                self.level_settings['victory'] = default_vic
        except Exception:
            self.level_settings['victory'] = {"collect_hearts": True, "move_to": None, "classes_present": False}

        # Old use_student_module/student_classes_in_subfolder flags deprecated (now using class_requirements from F4)

        # Load class requirements (F4 menu configuration)
        try:
            self.class_requirements = settings.get('class_requirements', {})
            if not isinstance(self.class_requirements, dict):
                self.class_requirements = {}
        except Exception:
            self.class_requirements = {}

        # Ensure victory settings present (backwards compatibility)
        self.level_settings.setdefault('victory', {"collect_hearts": True, "move_to": None, "classes_present": False})

        # Load hints (F5 configuration)
        self.hints = dict(settings.get('hints', {}) or {})

        self._recalc_window()
        self.screen = pygame.display.set_mode((self.win_w, self.win_h))

    def to_json(self):
        data = {"tiles": ["".join(row) for row in self.level]}
        # Immer Settings schreiben, auch wenn alle False sind
        data["settings"] = {k: {"public": not v} for k, v in self.privacy_flags.items()}
        # Orientierungen exportieren (falls gesetzt)
        if self.orientations:
            data["settings"].setdefault("orientations", {})
            data["settings"]["orientations"].update(self.orientations)
        # Farben für Türen/Schlüssel exportieren
        if self.colors:
            data["settings"].setdefault("colors", {})
            data["settings"]["colors"].update(self.colors)
        # Villager-Geschlechter exportieren
        if self.villagers:
            data["settings"].setdefault("villagers", {})
            data["settings"]["villagers"].update(self.villagers)
        # Quests exportieren
        if self.quests:
            data["settings"].setdefault("quests", {})
            data["settings"]["quests"].update(self.quests)
        # Zusätzliche Level-Einstellungen exportieren (falls gesetzt)
        if getattr(self, 'level_settings', None):
            for k, v in self.level_settings.items():
                # only export simple scalars
                try:
                    if v is None:
                        continue
                    data["settings"][k] = v
                except Exception:
                    continue
        # Export class requirements (F4 configuration)
        try:
            if hasattr(self, 'class_requirements') and self.class_requirements:
                data["settings"]["class_requirements"] = self.class_requirements
        except Exception:
            pass

        # Export hints (F5 configuration)
        try:
            if hasattr(self, 'hints') and self.hints:
                data["settings"]["hints"] = self.hints
        except Exception:
            pass
        
        # Export template_objects if rebuild_mode is enabled
        try:
            vic = self.level_settings.get('victory', {})
            if vic and vic.get('rebuild_mode', False):
                # Sammle alle Objekte aus dem Level als Templates
                template_objects = []
                type_map = {
                    'p': 'Held', 'k': 'Knappe', 'x': 'Monster', 'y': 'Bogenschuetze',
                    'h': 'Herz', 'd': 'Tuer', 'g': 'Tor', 's': 'Schluessel',
                    'c': 'Zettel', 'v': 'Villager', 't': 'Hindernis', 'm': 'Hindernis', 'b': 'Hindernis'
                }
                for y, row in enumerate(self.level):
                    for x, code in enumerate(row):
                        typ = type_map.get(code.lower())
                        if typ:
                            obj_data = {'typ': typ, 'x': x, 'y': y}
                            # Richtung hinzufügen falls gesetzt
                            richt = self.orientations.get(f"{x},{y}")
                            if richt:
                                obj_data['richtung'] = richt
                            # Farbe für Türen/Schlüssel
                            if code.lower() in ('d', 's'):
                                farbe = self.colors.get(f"{x},{y}")
                                if farbe:
                                    obj_data['farbe'] = farbe
                            # Geschlecht für Villager
                            if code.lower() == 'v':
                                vdata = self.villagers.get(f"{x},{y}", {})
                                if isinstance(vdata, dict) and vdata.get('weiblich'):
                                    obj_data['weiblich'] = True
                            # Hindernis-Typ
                            if code.lower() in ('t', 'm', 'b'):
                                hindernis_typ = {'t': 'Baum', 'm': 'Berg', 'b': 'Busch'}
                                obj_data['hindernis_typ'] = hindernis_typ.get(code.lower(), 'Baum')
                            template_objects.append(obj_data)
                data["settings"]["template_objects"] = template_objects
        except Exception as e:
            print(f"[WARNUNG] Fehler beim Exportieren der template_objects: {e}")
            pass
        
        return data


    def lade_dialog(self):
        root = tk.Tk(); root.withdraw()
        pfad = filedialog.askopenfilename(filetypes=[("JSON Level", "*.json")])
        root.destroy()
        if not pfad:
            return
        with open(pfad, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.from_json(data)
        print(f"[OK] Level geladen: {pfad}")

    def speichere_json(self, pfad):
        with open(pfad, "w", encoding="utf-8") as f:
            json.dump(self.to_json(), f, ensure_ascii=False, indent=2)
        print(f"[OK] Level gespeichert: {pfad}")

    def speicher_dialog(self):
        root = tk.Tk(); root.withdraw()
        pfad = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON Level", "*.json")])
        root.destroy()
        if pfad:
            self.speichere_json(pfad)

    # -----------------------------
    # Event-Loop
    # -----------------------------
    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.set_tile_at_mouse(self.selected_code)
                    elif event.button == 3:
                        self.set_tile_at_mouse(self.selected_code, right_click=True)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_F1:
                        self.open_privacy_menu()
                    elif event.key == pygame.K_F2:
                        self.open_settings_dialog()
                    elif event.key == pygame.K_F3:
                        self.open_victory_dialog()
                    elif event.key == pygame.K_F4:
                        self.open_class_requirements_dialog()
                    elif event.key == pygame.K_F5:
                        self.open_hints_dialog()
                    elif event.key == pygame.K_s:
                        self.speicher_dialog()
                    elif event.key == pygame.K_o:
                        self.lade_dialog()
                    elif event.key == pygame.K_RIGHT:
                        self.resize(+1, 0)
                    elif event.key == pygame.K_DOWN:
                        self.resize(0, +1)
                    elif event.key == pygame.K_LEFT:
                        self.resize(-1, 0)
                    elif event.key == pygame.K_UP:
                        self.resize(0, -1)
                    elif event.key == pygame.K_q:
                        # Quest konfigurieren / platzieren
                        self.open_quest_dialog()
                    elif pygame.K_0 <= event.key <= pygame.K_9:
                        self.handle_digit(chr(event.key))
                elif event.type == pygame.MOUSEWHEEL:
                    # Mausrad drehen => Orientierung ändern (Vorsicht: event.y positive = up)
                    self.rotate_orientation_at_mouse(event.y)
            self.draw()
            self.clock.tick(60)
        pygame.quit()

    # -----------------------------
    # Tastenauswertung
    # -----------------------------
    def handle_digit(self, key_str: str):
        # Zyklische Gruppe (Taste '2')
        if key_str in TILE_GROUPS:
            idx = (self.tile_cycle_idx[key_str] + 1) % len(TILE_GROUPS[key_str])
            self.tile_cycle_idx[key_str] = idx
            code, path = TILE_GROUPS[key_str][idx]
            if code not in self.sprites:
                self.sprites[code] = self._load_sprite(path)
            self.selected_code = code
            return

        # Held/Knappe Toggle (Taste '6')
        if key_str == "6":
            self._toggle_held_knappe = not self._toggle_held_knappe
            self.selected_code = "p" if self._toggle_held_knappe else "k"
            print("[Info] Auswahl:", "Held ('p')" if self._toggle_held_knappe else "Knappe ('k')")
            return

        # Monster variants (Taste '5'): cycle between default Monster ('x') and Bogenschuetze ('y')
        if key_str == "5":
            try:
                self.monster_variant_idx = (getattr(self, 'monster_variant_idx', 0) + 1) % 2
            except Exception:
                self.monster_variant_idx = 0
            # map index to code
            self.selected_code = 'x' if self.monster_variant_idx == 0 else 'y'
            # ensure sprite loaded
            if self.selected_code not in self.sprites:
                if self.selected_code == 'x':
                    self.sprites['x'] = self._load_sprite('sprites/monster.png')
                else:
                    self.sprites['y'] = self._load_sprite('sprites/archer.png')
            print(f"[Info] Monster-Variante: {'Monster' if self.selected_code=='x' else 'Bogenschuetze'}")
            return

        # Standardtiles
        # Tür-Farbwahl (Taste '8' cycle) — inkl. Möglichkeit für 'normale' Tür (None)
        if key_str == "8":
            total = len(self.door_colors) + 1
            self.door_color_idx = (self.door_color_idx + 1) % total
            if self.door_color_idx == 0:
                self.selected_door_color = None
                print("[Info] Normale Tür ausgewählt (keine Farbe)")
            else:
                self.selected_door_color = self.door_colors[self.door_color_idx - 1]
                print(f"[Info] Türfarbe ausgewählt: {self.selected_door_color}")
            self.selected_code = TILES.get(key_str, ("d",))[0]
            return

        # Schlüssel-Farbwahl (Taste '0' cycle) -> inkl. 'keine Auswahl' -> wählt 's' als Tile
        if key_str == "0":
            total_k = len(self.key_colors) + 1
            self.key_color_idx = (self.key_color_idx + 1) % total_k
            if self.key_color_idx == 0:
                self.selected_key_color = None
                print("[Info] Schlüssel: keine Farbauswahl (Default green beim Spawn)")
            else:
                self.selected_key_color = self.key_colors[self.key_color_idx - 1]
                print(f"[Info] Schlüssel-Farbe ausgewählt: {self.selected_key_color}")
            self.selected_code = "s"
            return

        # Villager variants / Questgeber (Taste '4')
        # Cycle: 0 = male villager, 1 = female villager, 2 = Questgeber (q)
        if key_str == "4":
            try:
                self.villager_variant_idx = (getattr(self, 'villager_variant_idx', 0) + 1) % 3
            except Exception:
                self.villager_variant_idx = 0
            if self.villager_variant_idx == 0:
                self.selected_villager_weiblich = False
                self.selected_code = "v"
                print("[Info] Villager: männlich ('v')")
            elif self.villager_variant_idx == 1:
                self.selected_villager_weiblich = True
                self.selected_code = "v"
                print("[Info] Villager: weiblich ('v')")
            else:
                # Questgeber selected
                self.selected_code = "q"
                print("[Info] Questgeber ausgewählt ('q')")
            return

        # Taste '7' toggelt zwischen Code-Zettel ('c') und normaler Tür ('d')
        if key_str == "7":
            if self.selected_code == "c":
                self.selected_code = "d"
                self.selected_door_color = None
                print("[Info] Auswahl: Tür (normale Tür)")
            else:
                self.selected_code = "c"
                print("[Info] Auswahl: Code-Zettel ('c')")
            return

        if key_str in TILES:
            self.selected_code = TILES[key_str][0]

    # -----------------------------
    # Mausrad / Orientierungen
    # -----------------------------
    def rotate_orientation_at_mouse(self, delta):
        """Delta int: positive = wheel up, negative = wheel down. Zyklisch: up->right->down->left."""
        mx, my = pygame.mouse.get_pos()
        gx = (mx - MARGIN) // self.tilesize
        gy = (my - MARGIN) // self.tilesize
        if not (0 <= gx < self.grid_w and 0 <= gy < self.grid_h):
            return
        code = self.level[gy][gx]
        # Nur für entitätstypen (veränderbar) reagieren; erweitert bei Bedarf
        if code.lower() not in ("p", "k", "x", "d", "g", "v"):
            return
        key = f"{gx},{gy}"
        dirs = ["up", "right", "down", "left"]
        cur = self.orientations.get(key, "down")
        idx = dirs.index(cur) if cur in dirs else 2
        idx = (idx + (1 if delta > 0 else -1)) % 4
        self.orientations[key] = dirs[idx]

    # -----------------------------
    # Resize
    # -----------------------------
    def resize(self, dx, dy):
        if dx != 0:
            if dx > 0:
                for row in self.level:
                    row.extend(["w"] * dx)
                self.grid_w += dx
            elif self.grid_w + dx >= MIN_W:
                for row in self.level:
                    for _ in range(-dx):
                        row.pop()
                self.grid_w += dx

        if dy != 0:
            if dy > 0:
                for _ in range(dy):
                    self.level.append(["w"] * self.grid_w)
                self.grid_h += dy
            elif self.grid_h + dy >= MIN_H:
                for _ in range(-dy):
                    self.level.pop()
                self.grid_h += dy

        self._recalc_window()
        self.screen = pygame.display.set_mode((self.win_w, self.win_h))


if __name__ == "__main__":
    LevelEditor().run()
