# grundlage.py
# Setup für lokales pygame (falls gebündelt)
try:
    from framework import setup_pygame
except ImportError:
    pass

from framework.framework import Framework
from .code import Code
from .held import Held
from .knappe import Knappe

# Platzhalter für globale Variablen, die beim Level-Laden gefüllt werden


class LevelManager:
    """Verwaltet den Ladevorgang der Level und stellt den Helden bereit."""
    def __init__(self):
        self.framework = None
        self.held = None

    def lade(self, nummer: int, weiblich = False,splash = False):
        global held,framework
        """Lädt das angegebene Level und initialisiert das Framework."""
        import sys

        self.framework = Framework(levelnummer=nummer, auto_erzeuge_objekte=True,w = weiblich,splash=splash)
        self.held = self.framework.spielfeld.held
        held = self.held
        framework = self.framework

        # Hinweis und Status zurücksetzen
        self.framework._hinweis = None
        self.framework._aktion_blockiert = False
        # Expose entity constructors in this module so student code that does
        # `from framework.grundlage import *` after calling level.lade(...) will
        # have convenient access to the classes referenced by the level.
        try:
            sp = getattr(self.framework, 'spielfeld', None)
        except Exception:
            sp = None

        # Export a full set of canonical entity/class names so students can
        # construct any framework object from `framework.grundlage` regardless
        # of whether the level actually spawns one. When student_mode is
        # enabled, only student-provided classes will be exported (so exercises
        # that require students to implement classes remain enforced).
        canonical_names = [
            'Held', 'Herz', 'Monster', 'Bogenschuetze', 'Code', 'Tuer',
            'Schluessel', 'Villager', 'Questgeber', 'Knappe', 'Tor', 'Hindernis', 'Gegenstand'
        ]

        # helper: import framework classes for fallbacks
        try:
            from .hindernis import Hindernis as _Hindernis
        except Exception:
            _Hindernis = None
        try:
            from .tuer import Tuer as _Tuer
        except Exception:
            _Tuer = None
        try:
            from .tor import Tor as _Tor
        except Exception:
            _Tor = None
        try:
            from .schluessel import Schluessel as _Schluessel
        except Exception:
            _Schluessel = None
        try:
            from .knappe import Knappe as _Knappe
        except Exception:
            _Knappe = None
        try:
            from .monster import Monster as _Monster, Bogenschuetze as _Bogenschuetze
        except Exception:
            _Monster = None; _Bogenschuetze = None
        try:
            from .herz import Herz as _Herz
        except Exception:
            _Herz = None
        try:
            from .code import Code as _Code
        except Exception:
            _Code = None
        try:
            from .villager import Villager as _Villager, Questgeber as _Questgeber
        except Exception:
            _Villager = None; _Questgeber = None

        # Decide whether student classes are enabled in this level
        try:
            settings = getattr(sp, 'settings', {}) or {}
            student_mode = bool(settings.get('import_pfad') or settings.get('use_student_module') or settings.get('student_classes_in_subfolder'))
            
            # Check if ANY class_requirements request student classes
            if not student_mode:
                class_reqs = settings.get('class_requirements', {})
                if isinstance(class_reqs, dict):
                    for cls_name, req in class_reqs.items():
                        if isinstance(req, dict):
                            if req.get('load_from_schueler') or req.get('load_from_klassen'):
                                student_mode = True
                                break
        except Exception:
            student_mode = False

        # Flexible wrapper factory to accept both (name,x,y) and (x,y,name)
        def _flexible_ctor(fwcls):
            def _ctor(*args, **kwargs):
                try:
                    # pattern: (name, x, y)
                    if len(args) >= 3 and isinstance(args[0], str) and isinstance(args[1], int) and isinstance(args[2], int):
                        name, x, y = args[0], args[1], args[2]
                        return fwcls(x, y, name, **kwargs)
                    # pattern: (x, y, name)
                    if len(args) >= 2 and isinstance(args[0], int) and isinstance(args[1], int):
                        x, y = args[0], args[1]
                        name = args[2] if len(args) > 2 else kwargs.get('name', None)
                        if name is None:
                            return fwcls(x, y, **kwargs)
                        return fwcls(x, y, name, **kwargs)
                    # fallback: try direct construction
                    return fwcls(*args, **kwargs)
                except Exception:
                    return fwcls(*args, **kwargs)
            return _ctor

        import sys as _sys
        _mod = _sys.modules.get(__name__)
        for cname in canonical_names:
            try:
                # map canonical to framework class for fallback
                fwcls = None
                if cname == 'Hindernis': fwcls = _Hindernis
                elif cname == 'Tuer': fwcls = _Tuer
                elif cname == 'Tor': fwcls = _Tor
                elif cname == 'Schluessel': fwcls = _Schluessel
                elif cname == 'Knappe': fwcls = _Knappe
                elif cname == 'Monster': fwcls = _Monster
                elif cname == 'Bogenschuetze': fwcls = _Bogenschuetze
                elif cname == 'Herz': fwcls = _Herz
                elif cname == 'Code': fwcls = _Code
                elif cname == 'Villager': fwcls = _Villager
                elif cname == 'Questgeber': fwcls = _Questgeber
                elif cname == 'Held':
                    # expose Held class wrapper that constructs the framework Held
                    try:
                        from .held import Held as _Held
                        fwcls = _Held
                    except Exception:
                        fwcls = None
                else:
                    fwcls = None

                cls = None
                try:
                    if sp is not None and fwcls is not None:
                        cls = sp._get_entity_class(cname, fwcls)
                    elif sp is not None:
                        cls = sp._get_entity_class(cname, None)
                    else:
                        cls = None
                except Exception:
                    cls = None

                # Decide export: if student_mode requested, only export student classes
                # EXCEPT in rebuild_mode: dort Framework-Klassen immer exportieren
                rebuild_mode = False
                try:
                    vic_settings = settings.get('victory', {})
                    rebuild_mode = bool(vic_settings.get('rebuild_mode', False))
                except Exception:
                    rebuild_mode = False
                
                if student_mode and not rebuild_mode:
                    # Student mode: prefer student classes but fallback to framework classes
                    if cls is None:
                        # No student class exists, use framework class
                        cls = fwcls
                    if cls is None:
                        # Neither student nor framework class available
                        if hasattr(_mod, cname):
                            try:
                                delattr(_mod, cname)
                            except Exception:
                                pass
                        continue
                    # Export class (student or framework fallback)
                    try:
                        if cls is fwcls and fwcls is not None:
                            setattr(_mod, cname, _flexible_ctor(fwcls))
                        else:
                            setattr(_mod, cname, cls)
                    except Exception:
                        try:
                            setattr(_mod, cname, cls)
                        except Exception:
                            pass
                elif student_mode and rebuild_mode:
                    # Rebuild mode with student mode: Do NOT export any classes
                    # Students must explicitly import from klassen.* themselves
                    # This forces them to write: from klassen.held import Held
                    if hasattr(_mod, cname):
                        try:
                            delattr(_mod, cname)
                        except Exception:
                            pass
                else:
                    # student mode not requested: export framework class (wrap if necessary)
                    if cls is None:
                        cls = fwcls
                    if cls is None:
                        continue
                    # if exporting an internal framework class that expects (x,y,...) but students
                    # may call (name,x,y), provide a flexible wrapper
                    try:
                        if cls is fwcls and fwcls is not None:
                            setattr(_mod, cname, _flexible_ctor(fwcls))
                        else:
                            setattr(_mod, cname, cls)
                    except Exception:
                        try:
                            setattr(_mod, cname, cls)
                        except Exception:
                            pass
            except Exception:
                continue
        
    def gib_objekt_bei(self,x,y):
        obj = framework.gib_objekt_an(x,y)
        if obj is not None:
            try:
                import inspect as _inspect, re as _re
                _frame = _inspect.currentframe().f_back
                _ctx = _inspect.getframeinfo(_frame).code_context
                _varname = None
                if _ctx:
                    _match = _re.match(r'^([a-zA-Z_][a-zA-Z0-9_]*)\s*=', _ctx[0].strip())
                    if _match:
                        _varname = _match.group(1)
                fw = getattr(self, 'framework', None) or framework
                if fw and hasattr(fw, '_register_inspector_ref'):
                    fw._register_inspector_ref(obj, _varname)
            except Exception:
                pass
        return obj

    def objekt_hinzufuegen(self, obj):
        """Convenience: forward to the active framework instance so students
        can call `level.objekt_hinzufuegen(obj)` directly from their code.
        """
        try:
            fw = getattr(self, 'framework', None)
            if fw is None:
                # fallback to module-level framework if available
                try:
                    from framework import grundlage as _g
                    fw = getattr(_g, 'framework', None)
                except Exception:
                    fw = None
            if fw is None:
                raise AttributeError('Kein Framework vorhanden')
            return fw.objekt_hinzufuegen(obj)
        except Exception:
            # Bubble up the AttributeError to make student errors visible
            raise
        
 
"""
def __getattr__(name):
    if name == "held":
        return level.framework.spielfeld.held
    if name == "framework":
        return level.framework
    raise AttributeError(name)
"""




# Globale Instanz
global held, framework
level = LevelManager()
held = None
framework = None
tuer = None
code = None
monster = None


# Optional: Direkter Start bei eigenständigem Aufruf (z. B. Test)
"""
if __name__ == "__main__":
    level.lade(1)
    framework.starten()
"""
