from framework.grundlage import level
level.lade(0,weiblich=True)
from framework.grundlage import *
# Ab hier darfst du programmieren:


# Dieser Befehl muss immer am Ende stehen
framework.starten()
