# framework/objekt.py
import pygame
from .utils import richtung_offset,richtung_offset2, lade_sprite, RICHTUNGEN
import os
import inspect
import sys

# Central, editable privacy rules: map class/typ name -> set of attribute names
# that should be blocked when an object's _privatmodus is active. You can
# customize this dictionary at runtime (e.g. in a small setup script) to
# change which attributes are considered private for each class.
#
# By default we preserve legacy behavior: protect positional/orientation
# attributes for most entities and 'offen' for doors; additionally we add
# entries for keys and the archer (Bogenschuetze).
PRIVACY_RULES = {
    "Held": {"x", "y", "r", "richtung"},
    "Knappe": {"x", "y", "r", "richtung"},
    "Monster": {"x", "y", "r", "richtung"},
    "Bogenschuetze": {"x", "y", "r", "richtung"},
    "Herz": {"x", "y" },
    "Tuer": {"x", "y", "offen", "farbe", "color","richtiger_code", "key_color"},
    "Code": {"x", "y","code"},
    "Villager": {"x", "y", "r", "richtung"},
    "Hindernis": {"x", "y","typ"},
    "Schluessel": {"x", "y", "farbe", "color","farbe"},
}


class Objekt:
    def __init__(self, typ, x=0, y=0, richtung="down", sprite_pfad=None, name=None):
        self._privatmodus = False
        self.typ = typ                    # "Held", "Monster", "Herz", ...
        self.name = name or typ           # Anzeigename, z. B. "Harribert"
        self.x = x
        self.y = y
        self.richtung = richtung
        self.sprite_pfad = sprite_pfad
        self.bild = lade_sprite(sprite_pfad)
        self.framework = None
        self.tot = False
        self._herzen = 0
        self._kills = 0
        
        self._update_sprite_richtung()
        
    def set_privatmodus(self, aktiv: bool):
        # Silence status messages when toggling private mode; keep behavior
        # of setting the internal flag.
        self._privatmodus = aktiv
        
    def setze_richtung(self,r):
        # Accept English canonical, single-letter abbreviations, and German names
        if not isinstance(r, str):
            print("Ungültige Richtungsangabe!")
            return
        norm = r.strip().lower()
        mapping = {
            'up': 'up', 'n': 'up', 'north': 'up', 'norden': 'up',
            'down': 'down', 's': 'down', 'south': 'down', 'süden': 'down', 'sueden': 'down',
            'left': 'left', 'w': 'left', 'west': 'left', 'westen': 'left',
            'right': 'right', 'o': 'right', 'east': 'right', 'osten': 'right', 'ost': 'right'
        }
        canon = mapping.get(norm)
        if canon is None:
            # try replacing umlauts
            alt = norm.replace('ü', 'ue').replace('ö', 'oe').replace('ä', 'ae')
            canon = mapping.get(alt)

        if canon is None:
            print("Ungültige Richtungsangabe!")
            return
        # set canonical
        self.richtung = canon
        self._update_sprite_richtung()
            
    def setze_position(self, x, y):
        """Setzt die Position nur, wenn (x,y) im Spielfeld liegt,
        das Terrain dort 'Weg' ist und kein anderes Objekt dort steht."""
        sp = getattr(self, "framework", None)
        sp = getattr(sp, "spielfeld", None) if sp else None
        if not sp:
            print("[Warnung] Kein Spielfeld vorhanden – setze_position() abgebrochen.")
            return False

        # 1) Grenzen prüfen
        if not sp.innerhalb(x, y):
            print(f"[{self.typ}] Position außerhalb des Spielfelds: ({x},{y})")
            return False

        # 2) Terrain muss 'Weg' sein
        if sp.terrain_art_an(x, y) != "Weg":
            print(f"[{self.typ}] Feld ({x},{y}) ist kein begehbarer Weg.")
            return False

        # 3) Feld muss leer sein (kein anderes Objekt)
        occupant = sp.objekt_an(x, y)
        if occupant is not None and occupant is not self:
            print(f"[{self.typ}] Position ({x},{y}) ist bereits belegt ({occupant.typ}).")
            return False

        # 4) Setzen + kurzer sichtbarer Refresh
        self.x, self.y = x, y
        self._render_and_delay(150)
        print(f"[{self.typ}] wurde nach ({x},{y}) gesetzt.")
        return True


        
    

    def __getattribute__(self, name):
        if name.startswith("_"):
            return object.__getattribute__(self, name)

        # Framework-internal callers should be allowed. Detect callers by
        # module name (preferred) or by an exact '/framework/' path segment
        # to avoid false positives for repository names containing 'framework'.
        try:
            frm = sys._getframe(1)
            caller_mod = frm.f_globals.get('__name__', '')
            caller_file = frm.f_code.co_filename.replace('\\', '/')
        except Exception:
            caller_mod = ''
            caller_file = ''

        if isinstance(caller_mod, str) and (caller_mod == 'framework' or caller_mod.startswith('framework.')):
            return object.__getattribute__(self, name)
        if '/framework/' in caller_file:
            return object.__getattribute__(self, name)

        try:
            privat = object.__getattribute__(self, "_privatmodus")
        except Exception:
            privat = False
        if privat:
            # Determine which attributes are considered private for this object's
            # type. The global PRIVACY_RULES dict is editable at runtime; if no
            # explicit rule is present we fall back to legacy defaults.
            try:
                typ = object.__getattribute__(self, 'typ')
            except Exception:
                typ = None

            # choose rule set: explicit mapping if present, otherwise fallback
            if typ in PRIVACY_RULES:
                priv_attrs = PRIVACY_RULES.get(typ, set()) or set()
            else:
                # legacy default: block position/orientation for most entities
                priv_attrs = {"x", "y", "r", "richtung"}
                # doors additionally block 'offen'
                if typ == 'Tuer':
                    priv_attrs.add('offen')

            if name in priv_attrs:
                raise AttributeError(f"Attribut '{name}' ist privat – Zugriff nicht erlaubt")

        return object.__getattribute__(self, name)


    def __setattr__(self, name, value):
        # interne Variablen dürfen immer gesetzt werden
        if name.startswith("_"):
            return object.__setattr__(self, name, value)
        

        try:
            frm = sys._getframe(1)
            caller_mod = frm.f_globals.get('__name__', '')
            caller_file = frm.f_code.co_filename.replace('\\', '/')
        except Exception:
            caller_mod = ''
            caller_file = ''

        if isinstance(caller_mod, str) and (caller_mod == 'framework' or caller_mod.startswith('framework.')):
            return object.__setattr__(self, name, value)
        if '/framework/' in caller_file:
            return object.__setattr__(self, name, value)

        if object.__getattribute__(self, "_privatmodus"):
            try:
                typ = object.__getattribute__(self, 'typ')
            except Exception:
                typ = None

            if typ in PRIVACY_RULES:
                priv_attrs = PRIVACY_RULES.get(typ, set()) or set()
            else:
                priv_attrs = {"x", "y", "r", "richtung"}
                if typ == 'Tuer':
                    priv_attrs.add('offen')

            if name in priv_attrs:
                raise AttributeError(f"Attribut '{name}' ist privat – Schreiben nicht erlaubt")

        object.__setattr__(self, name, value)


 
     
    """
    def __getattribute__(self, name):
        # Zugriff auf private Attribute verbieten, wenn der Modus aktiv ist
        if name in ("x", "y", "richtung", "leben", "herzen") and object.__getattribute__(self, "_privatmodus"):
            raise AttributeError(f"Attribut '{name}' ist privat – Zugriff nicht erlaubt")
        return object.__getattribute__(self, name)
            
        def verbleibende_herzen(self):
            return self.framework.spielfeld.anzahl_herzen()
    """
        
    def getX(self):
        return self.x
    
    def verbleibende_herzen(self):
            sp = getattr(self, "framework", None)
            sp = getattr(sp, "spielfeld", None) if sp else None
            if not sp:
                try:
                    import framework.grundlage as grundlage
                    fw = getattr(grundlage, 'framework', None)
                    sp = getattr(fw, 'spielfeld', None) if fw else None
                except Exception:
                    sp = None
            if not sp:
                print("[Warnung] Kein Spielfeld vorhanden – verbleibende_herzen() abgebrochen.")
                return 0
            return sp.anzahl_herzen()

        
    def _ungueltige_aktion(self, meldung="Ungültige Aktion"):
        if self.framework:
            # Nur blockieren, wenn nicht über Tastatur ausgelöst
            if not getattr(self.framework, "_aus_tastatur", False):
                self.framework.stoppe_programm(meldung)
            else:
                # Tastatur: nur Hinweis ausgeben, aber weiterlaufen
                self.framework._hinweis = meldung



    # ---- sichtbare Verzögerung, inklusive Render ----
    def _render_and_delay(self, ms=0):
        # Resolve framework instance that provides _render_frame()
        fw = getattr(self, 'framework', None)
        if not fw or not hasattr(fw, '_render_frame'):
            try:
                import framework.grundlage as grundlage
                fw = getattr(grundlage, 'framework', None)
            except Exception:
                fw = None

        if not fw:  # falls außerhalb genutzt
            if ms > 0:
                pygame.time.wait(ms)
            return

        fw._render_frame()
        if ms > 0:
            # aktiv warten, Events pumpen, damit Fenster responsiv bleibt
            start = pygame.time.get_ticks()
            while pygame.time.get_ticks() - start < ms:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        # Avoid calling pygame.quit() here (can hang in some IDEs).
                        # Signal the framework main loop to stop and return to the caller.
                        try:
                            if fw and hasattr(fw, '_running'):
                                fw._running = False
                        except Exception:
                            pass
                        return
                try:
                    fw._render_frame()
                except Exception:
                    pass
                pygame.time.delay(16)  # ~60 FPS

    # ---- Aktionen (Baseline: direkt ausführen + sichtbar machen) ----
    def geh(self, delay_ms=500):
        # Respect global action-block flag when available
        fw = getattr(self, 'framework', None)
        if fw and getattr(fw, '_aktion_blockiert', False):
            return

        # Obtain spielfeld robustly (allow cases where self.framework may not be the Framework)
        sp = None
        if fw is not None:
            sp = getattr(fw, 'spielfeld', None)
        if not sp:
            try:
                import framework.grundlage as grundlage
                fw2 = getattr(grundlage, 'framework', None)
                sp = getattr(fw2, 'spielfeld', None) if fw2 else None
            except Exception:
                sp = None

        if self.tot or not sp:
            return

        dx, dy = richtung_offset(self.richtung)
        nx, ny = self.x + dx, self.y + dy

        # 1️⃣ Prüfe, ob das Ziel betretbar ist
        if not sp.kann_betreten(self, nx, ny):
            mon = sp.finde_monster(nx, ny)
            if mon and self.typ == "Held" and sp.ist_frontal_zu_monster(self, mon):
                # Held läuft in Monster hinein → stirbt
                self.tot = True
                self._update_sprite_richtung()
                self._render_and_delay(100)
                return
            # Ungültige Bewegung (z. B. Wand, Baum, Tür)
            if not getattr(fw, '_aus_tastatur', False):
                try:
                    self._ungueltige_aktion("Ungültige Aktion. Versuch es nochmal!")
                except Exception:
                    pass
            print("["+self.typ+"] Dahin kann ich nicht gehen!")
            return

        # 2️⃣ Bewegung ist gültig → Koordinaten übernehmen
        self.x, self.y = nx, ny
        self._render_and_delay(delay_ms)
        
    def zurueck(self, delay_ms=500):
        fw = getattr(self, 'framework', None)
        if fw and getattr(fw, '_aktion_blockiert', False):
            return

        # resolve spielfeld
        sp = None
        if fw is not None:
            sp = getattr(fw, 'spielfeld', None)
        if not sp:
            try:
                import framework.grundlage as grundlage
                fw2 = getattr(grundlage, 'framework', None)
                sp = getattr(fw2, 'spielfeld', None) if fw2 else None
            except Exception:
                sp = None

        if self.tot or not sp:
            return

        dx, dy = richtung_offset2(self.richtung)
        nx, ny = self.x + dx, self.y + dy

        # 1️⃣ Prüfe, ob das Ziel betretbar ist
        if not sp.kann_betreten(self, nx, ny):
            mon = sp.finde_monster(nx, ny)
            if mon and self.typ == "Held" and sp.ist_frontal_zu_monster(self, mon):
                self.tot = True
                self._update_sprite_richtung()  # 🔧 KO-Grafik laden
                self._render_and_delay(delay_ms)
                return

            # Ungültige Bewegung (z. B. Wand, Baum, Tür)
            if not getattr(fw, '_aus_tastatur', False):
                try:
                    self._ungueltige_aktion("Ungültige Aktion. Versuch es nochmal!")
                except Exception:
                    pass
            print("["+self.typ+"] Dahin kann ich nicht gehen!")
            return

        # 2️⃣ Bewegung ist gültig → Koordinaten übernehmen
        self.x, self.y = nx, ny
        self._render_and_delay(delay_ms)


    def links(self, delay_ms=500):
        if self.framework and getattr(self.framework, "_aktion_blockiert", False):
            return
        if self.tot: return
        idx = (RICHTUNGEN.index(self.richtung) - 1) % 4
        self.richtung = RICHTUNGEN[idx]
        self._update_sprite_richtung()
        self._render_and_delay(delay_ms)

    def rechts(self, delay_ms=500):
        if self.framework and getattr(self.framework, "_aktion_blockiert", False):
            return
        if self.tot: return
        idx = (RICHTUNGEN.index(self.richtung) + 1) % 4
        self.richtung = RICHTUNGEN[idx]
        self._update_sprite_richtung()
        self._render_and_delay(delay_ms)
        
        
    def nimm_herz(self,delay_ms=500):
        self.nehme_auf(delay_ms)

    def nehme_auf(self, delay_ms=500):
        fw = getattr(self, 'framework', None)
        if fw and getattr(fw, '_aktion_blockiert', False):
            return
        if self.typ not in ["Held","Knappe"]:
            self._ungueltige_aktion("Dieses Objekt darf keine Herzen nehmen!")
            return

        # resolve spielfeld
        sp = None
        if fw is not None:
            sp = getattr(fw, 'spielfeld', None)
        if not sp:
            try:
                import framework.grundlage as grundlage
                fw2 = getattr(grundlage, 'framework', None)
                sp = getattr(fw2, 'spielfeld', None) if fw2 else None
            except Exception:
                sp = None

        if self.tot or not sp:
            return

        herz = sp.finde_herz(self.x, self.y)
        if herz:
            sp.entferne_objekt(herz)
            self._herzen += 1
            # reward gold to holder if configured
            try:
                from .config import HEART_GOLD
                if hasattr(self, 'gold'):
                    try:
                        self.gold = int(getattr(self, 'gold', 0) or 0) + int(HEART_GOLD)
                    except Exception:
                        # best-effort: set to HEART_GOLD
                        try:
                            self.gold = int(HEART_GOLD)
                        except Exception:
                            pass
            except Exception:
                # config not available or other issue — ignore
                pass
            self._render_and_delay(delay_ms)
            """
            if not self.framework.spielfeld.gibt_noch_herzen() and not self.framework._aktion_blockiert:
                self.framework.sieg()"""

        else:
            if not self.framework._aus_tastatur:
                self._ungueltige_aktion("Ungültige Aktion! Versuch es nochmal!")
            print("["+self.typ+"] Hier liegt kein Herz!")
            return

    def attack(self, delay_ms=500):
        """Nur Held darf angreifen – alle anderen ignorieren."""
        if self.typ != "Held":
            self._ungueltige_aktion("Dieses Objekt kann nicht angreifen!")
            return

    
#    def _zeige_angriff_sprite(self):
#        """Wechselt temporär zum Angriffssprite, falls vorhanden."""
#        t = self.sprite_pfad.copy()
#        base = self.sprite_pfad.split(".png")[0]
#        att_pfad = f"{base}_att.png"
#        try:
#            self.bild = pygame.image.load(att_pfad).convert_alpha()
#            self._render_and_delay(150)
#            return t
#        except FileNotFoundError:
#            pass  # kein Angriffssprite vorhanden
    


    # ---- Wahrnehmung / Infos (für Schüler) ----
    def was_ist_vorn(self):
        fw = getattr(self, 'framework', None)
        if fw and getattr(fw, '_aktion_blockiert', False):
            return
        dx, dy = richtung_offset(self.richtung)
        tx, ty = self.x + dx, self.y + dy
        sp = None
        if fw is not None:
            sp = getattr(fw, 'spielfeld', None)
        if not sp:
            try:
                import framework.grundlage as grundlage
                fw2 = getattr(grundlage, 'framework', None)
                sp = getattr(fw2, 'spielfeld', None) if fw2 else None
            except Exception:
                sp = None
        if not sp:
            return None
        return sp.objekt_art_an(tx, ty) or sp.terrain_art_an(tx, ty)
    
    def was_ist_links(self):
        fw = getattr(self, 'framework', None)
        if fw and getattr(fw, '_aktion_blockiert', False):
            return
        i = RICHTUNGEN.index(self.richtung)
        links_richtung = RICHTUNGEN[(i - 1) % 4]
        dx, dy = richtung_offset(links_richtung)
        tx, ty = self.x + dx, self.y + dy
        sp = None
        if fw is not None:
            sp = getattr(fw, 'spielfeld', None)
        if not sp:
            try:
                import framework.grundlage as grundlage
                fw2 = getattr(grundlage, 'framework', None)
                sp = getattr(fw2, 'spielfeld', None) if fw2 else None
            except Exception:
                sp = None
        if not sp:
            return None
        return sp.objekt_art_an(tx, ty) or sp.terrain_art_an(tx, ty)
    
    def was_ist_rechts(self):
        fw = getattr(self, 'framework', None)
        if fw and getattr(fw, '_aktion_blockiert', False):
            return
        i = RICHTUNGEN.index(self.richtung)
        rechts_richtung = RICHTUNGEN[(i + 1) % 4]
        dx, dy = richtung_offset(rechts_richtung)
        tx, ty = self.x + dx, self.y + dy
        sp = None
        if fw is not None:
            sp = getattr(fw, 'spielfeld', None)
        if not sp:
            try:
                import framework.grundlage as grundlage
                fw2 = getattr(grundlage, 'framework', None)
                sp = getattr(fw2, 'spielfeld', None) if fw2 else None
            except Exception:
                sp = None
        if not sp:
            return None
        return sp.objekt_art_an(tx, ty) or sp.terrain_art_an(tx, ty)

    def gib_objekt_vor_dir(self):
        """Gibt das erste Objekt auf dem Feld vor diesem Objekt zurück (oder None).
        Verwendet immer self.richtung und self.framework.spielfeld."""
        sp = getattr(self, "framework", None)
        sp = getattr(sp, "spielfeld", None) if sp else None
        if not sp:
            try:
                import framework.grundlage as grundlage
                fw2 = getattr(grundlage, 'framework', None)
                sp = getattr(fw2, 'spielfeld', None) if fw2 else None
            except Exception:
                sp = None
        if not sp:
            return None
        richt = getattr(self, "richtung", "down")
        dx, dy = richtung_offset(richt)
        tx, ty = getattr(self, "x", 0) + dx, getattr(self, "y", 0) + dy
        return sp.objekt_an(tx, ty)

    def ist_auf_herz(self):
        """
        if self.typ not in ["Held","Knappe"]:
            self._ungueltige_aktion("Dieses Objekt darf das nicht!")
            return
        """
        fw = getattr(self, 'framework', None)
        if fw and getattr(fw, '_aktion_blockiert', False):
            return
        sp = None
        if fw is not None:
            sp = getattr(fw, 'spielfeld', None)
        if not sp:
            try:
                import framework.grundlage as grundlage
                fw2 = getattr(grundlage, 'framework', None)
                sp = getattr(fw2, 'spielfeld', None) if fw2 else None
            except Exception:
                sp = None
        if not sp:
            return False
        return bool(sp.finde_herz(self.x, self.y))
    
    def herzen_vor_mir(self):
        """Zählt, wie viele Herzen in Sichtlinie liegen – einschließlich des Felds, auf dem das Objekt steht.
        Stoppt bei Hindernis oder Monster. Das eigene Objekt blockiert nicht."""
        sp = getattr(self, "framework", None)
        sp = getattr(sp, "spielfeld", None) if sp else None
        if not sp:
            print("[Warnung] Kein Spielfeld vorhanden – herzen_vor_mir() abgebrochen.")
            return 0

        dx, dy = richtung_offset(self.richtung)
        x, y = self.x, self.y  # beginne beim aktuellen Feld
        count = 0

        # Solange innerhalb des Spielfelds
        while sp.innerhalb(x, y):
            terrain = sp.terrain_art_an(x, y)
            if terrain != "Weg":
                break  # Hindernis (Baum, Mauer, etc.)

            # Zähle Herz, auch wenn es auf demselben Feld wie das Objekt liegt
            herz = sp.finde_herz(x, y)
            if herz:
                count += 1

            obj = sp.objekt_an(x, y)
            if obj:
                # Das eigene Objekt soll die Sichtlinie nicht blockieren
                if obj is self:
                    pass
                elif obj.typ.lower() == "monster":
                    break  # Sichtlinie blockiert
                elif obj.typ.lower() == "herz":
                    # Herz wurde bereits über finde_herz gezählt
                    pass
                else:
                    break  # anderes Objekt blockiert

            # Ein Feld weiter in Blickrichtung
            x += dx
            y += dy

        return count


    # ---- Zeichnen + Attributanzeige ----
    def zeichne(self, screen, feldgroesse):
        # Check if this object should not be rendered at all
        if getattr(self, '_dont_render', False):
            return
        
        # Check if we should show an error sprite instead
        if getattr(self, '_show_error_sprite', False):
            # Create a red question mark sprite programmatically
            error_surface = pygame.Surface((feldgroesse, feldgroesse))
            error_surface.fill((200, 0, 0))  # Red background
            font = pygame.font.Font(None, int(feldgroesse * 0.8))
            text = font.render('?', True, (255, 255, 255))  # White question mark
            text_rect = text.get_rect(center=(feldgroesse // 2, feldgroesse // 2))
            error_surface.blit(text, text_rect)
            screen.blit(error_surface, (self.x * feldgroesse, self.y * feldgroesse))
            return
        
        img = pygame.transform.scale(self.bild, (feldgroesse, feldgroesse))
        screen.blit(img, (self.x * feldgroesse, self.y * feldgroesse))

    def attribute_als_text(self):
        return {}
        """
        return {
            "name": self.name, "x": self.x, "y": self.y,
            "richtung": self.richtung
        }
        """
    
    def _update_sprite_richtung(self):
        """Lädt automatisch das passende Richtungs-Sprite, falls vorhanden."""
        if not self.sprite_pfad:
            return
        if self.tot:
            # Try several KO sprite naming variants:
            # 1) exact basename + _ko (e.g. sprites/held_left_ko.png)
            # 2) if basename ends with a direction suffix, try removing it and using base_ko
            basis = os.path.splitext(self.sprite_pfad)[0]
            candidates = [f"{basis}_ko.png"]
            try:
                # detect and strip direction suffix if present
                tail = basis.rsplit('_', 1)[-1].lower()
                if tail in ("up", "down", "left", "right", "n", "s", "w", "o", "N", "S", "W", "O"):
                    base_without_dir = basis.rsplit('_', 1)[0]
                    candidates.append(f"{base_without_dir}_ko.png")
            except Exception:
                pass

            for ko_pfad in candidates:
                try:
                    if os.path.exists(ko_pfad):
                        # use framework loader for consistency
                        self.bild = lade_sprite(ko_pfad)
                        try:
                            self.bild.set_alpha(220)
                        except Exception:
                            pass
                        return
                except Exception:
                    continue

            # Fallback: rotes Rechteck, falls kein KO-Sprite existiert
            try:
                self.bild = pygame.Surface((64, 64), pygame.SRCALPHA)
                self.bild.fill((180, 0, 0, 180))
            except Exception:
                pass
            return


        basis = os.path.splitext(self.sprite_pfad)[0]
        pfad_gerichtet = f"{basis}_{self.richtung}.png"
        if os.path.exists(pfad_gerichtet):
            self.bild = lade_sprite(pfad_gerichtet)
            
    def transmute_richtung(self,r):
        if r=="down":
            return "S"
        elif r=="up":
            return "N"
        elif r=="left":
            return "W"
        elif r=="right":
            return "O"
        elif r=="N":
            return "up"
        elif r=="O":
            return "right"
        elif r=="W":
            return "left"
        elif r=="S":
            return "down"

